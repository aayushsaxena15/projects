import nltk	
import sys
import re

a0 = '../dataset/match1/mom.txt'
a1 = '../dataset/match1/odi1_inn1_bat.txt'
a2 = '../dataset/match1/odi1_inn2_bat.txt'
a3 = '../dataset/match1/odi1_inn1_bowl.txt'
a4 = '../dataset/match1/odi1_inn2_bowl.txt'
a5 = '../dataset/match1/wonby.txt'
a6 = '../dataset/match1/toss'
a7 = '../dataset/match1/commentary_nz.txt'
a8 = '../dataset/match1/commentary_in.txt'

b0 = '../dataset/match2/mom.txt'
b1 = '../dataset/match2/odi2_inn1_bat.txt'
b2 = '../dataset/match2/odi2_inn2_bat.txt'
b3 = '../dataset/match2/odi2_inn1_bowl.txt'
b4 = '../dataset/match2/odi2_inn2_bowl.txt'
b5 = '../dataset/match2/wonby.txt'
b6 = '../dataset/match2/toss'
b7 = '../dataset/match2/commentary_nz.txt'
b8 = '../dataset/match2/commentary_in.txt'

c0 = '../dataset/match3/mom.txt'
c1 = '../dataset/match3/odi3_inn1_bat.txt'
c2 = '../dataset/match3/odi3_inn2_bat.txt'
c3 = '../dataset/match3/odi3_inn1_bowl.txt'
c4 = '../dataset/match3/odi3_inn2_bowl.txt'
c5 = '../dataset/match3/wonby.txt'
c6 = '../dataset/match3/toss'
c7 = '../dataset/match3/commentary_nz.txt'
c8 = '../dataset/match3/commentary_in.txt'

d0 = '../dataset/match4/mom.txt'
d1 = '../dataset/match4/odi4_inn1_bat.txt'
d2 = '../dataset/match4/odi4_inn2_bat.txt'
d3 = '../dataset/match4/odi4_inn1_bowl.txt'
d4 = '../dataset/match4/odi4_inn2_bowl.txt'
d5 = '../dataset/match4/wonby.txt'
d6 = '../dataset/match4/toss'
d7 = '../dataset/match4/commentary_nz.txt'
d8 = '../dataset/match4/commentary_in.txt'

e0 = '../dataset/match5/mom.txt'
e1 = '../dataset/match5/odi5_inn1_bat.txt'
e2 = '../dataset/match5/odi5_inn2_bat.txt'
e3 = '../dataset/match5/odi5_inn1_bowl.txt'
e4 = '../dataset/match5/odi5_inn2_bowl.txt'
e5 = '../dataset/match5/wonby.txt'
e6 = '../dataset/match5/toss'
e7 = '../dataset/match5/commentary_nz.txt'
e8 = '../dataset/match5/commentary_in.txt'

ind = '../dataset/player_profile/indian_players_profile.txt'
kiwi = '../dataset/player_profile/nz_players_profile.txt'

wonby = [a5,b5,c5,d5,e5]
toss = [a6,b6,c6,d6,e6]
first_bat = [a1,b1,c1,d1,e1]
second_bat = [a2,b2,c2,d2,e2]
first_bowl = [a3,b3,c3,d3,e3]
second_bowl = [a4,b4,c4,d4,e4]
kiwi_commentary = [a7,b7,c7,d7,e7]
in_commentary = [a8,b8,c8,d8,e8]

def add_to_dict(dictionary,fname):
	fp=open(fname, 'r')
	for line in fp:
		temp=line[:-1]
		temp=temp.split(',')
		a=temp[0]
		b=temp[1:]
		if a not in dictionary:
			dictionary[a] = b

indian_players = {}
add_to_dict(indian_players, ind)
kiwi_players = {}
add_to_dict(kiwi_players, kiwi)
indian_names = []
kiwi_names = []
for key in indian_players.keys():
        indian_names.append( (key.split('\t'))[0])
for key in kiwi_players.keys():
        kiwi_names.append( (key.split('\t'))[0])
all_names = indian_names + kiwi_names







import re

def findmatch(a):
        matches = ['first match','second match','third match','fourth match','fifth match']
        for i in range(0,len(matches)):
                if matches[i] in a:
                        return i
        return 6     
        
def parse_for_players(x):
        temp=[]
        phrases=x.split()
        for phrase in phrases:
                for name in all_names:
                        if name.split()[-1] in phrase:
                                temp.append(name)
        return temp

def find_specific_over_no(x):
        temp=re.findall("over (\d+)",x)
        if not len(temp):
                return -1
        return int(temp[0])

def parse_for_query(x):
        flags = [0,0,0,0,0,0,0]
        quantity = [0,0,0,0,0,0,0]
        contenders=['one','two','fours','six','out','wides','no ball']
        for i in range(0,len(contenders)):
                if contenders[i] in x:
                        flags[i] = 1
                if 'maximum '+contenders[i] in x:
                        quantity[i] = -1
                else:
                        num = re.findall("(\d+) "+contenders[i],x)
                        if len(num):
                                quantity[i] = int(num[0])
        return flags,quantity

def parse_for_questions(x):
        flags = [0,0,0,0,0]
        strings = ['which ball','which over','who dismissed','who hit','which bowler']
        for i in range(0,len(strings)):
                if strings[i] in x:
                        flags[i] = 1
        return flags



def solve_pre_batsmen(data,players,tempx):

        def verify(num,tempx):
                if tempx == 0 or tempx == 1:
                        if num == tempx + 1:
                                return 1
                if tempx == 2 or tempx == 3:
                        if num == 2*tempx:
                                return 1
                return 0
        
        ans = []
        for k in players:
                temp_str = data.split(',')
                for i in range(0,len(temp_str)-1):
                        part = temp_str[i]
                        if 'to '+str(k.split()[-1]) in part and k!= 'I Sharma':
                                string = temp_str[i+1].split()[0]
                                if string == 'SIX':
                                        num = 6
                                elif string == 'FOUR':
                                        num = 4
                                elif string == '1' or string == '2':
                                        num = int(string)
                                else:
                                        num = -1
                                if verify(num,tempx):
                                        tmp_ans = []
                                        tmp_ans.append(part.split()[-3])
                                        tmp_ans.append(k)
                                        tmp_ans.append(num)
                                        tmp_ans.append(part.split('\n')[-2])
                                        ans.append(tmp_ans)
        return ans

def solve_for_batsmen(pre,players,quantity,question):
        ans = []
        if quantity == 0:
                if question[0] == 1 or question[1] == 1 or question[4] == 1:
                        for row in pre:
                                tmp  = []
                                if question[4] == 1:
                                        tmp.append(row[0])
                                tmp.append(row[1])
                                tmp.append(row[2])
                                if question[0] == 1:
                                        tmp.append(row[3].split('.')[1])
                                if question[1] == 1:
                                        tmp.append(row[3].split('.')[0])
                                if tmp not in ans:
                                        ans.append(tmp)
                else:
                        ans = pre 
        elif quantity == -1:
                if question[3] == 1:
                        tmp = {}
                        for row in pre:
                                if row[1] not in tmp:
                                        tmp[row[1]] = 1
                                else:
                                        tmp[row[1]] += 1
                        maximum = 0
                        for key in tmp:
                                if tmp[key] > maximum:
                                        maximum = tmp[key]
                                        name = key
                        ans.append([name,tmp[name]])
                else:
                        if question[4] == 1:
                                tmp = {}
                                for row in pre:
                                        if row[0] not in tmp:
                                                tmp[row[0]] = 1
                                        else:
                                                tmp[row[0]] += 1
                                maximum = 0
                                for key in tmp:
                                        if tmp[key] > maximum:
                                                maximum = tmp[key]
                                for key in tmp:
                                        if maximum == tmp[key]:
                                                ans.append([players[0],key,tmp[key]])
                        if question[1] == 1:
                                tmp = {}
                                for row in pre:
                                        key = row[3].split('.')[0]
                                        if key not in tmp:
                                                tmp[key] = 1
                                        else:
                                                tmp[key] += 1
                                maximum = 0
                                for key in tmp:
                                        if tmp[key] > maximum:
                                                maximum = tmp[key]
                                for key in tmp:
                                        if maximum == tmp[key]:
                                                ans.append([players[0],key,tmp[key]])
        else:
                tmp = {}
                if question[4] == 1:
                        tmp2 = {}
                        for row in pre:
                                if row[0] not in tmp2:
                                        tmp2[row[0]] = 1
                                else:
                                        tmp2[row[0]] += 1
                        for k in tmp2:
                                if tmp2[k] == quantity:
                                        ans.append(k)
                if question[1] == 1:
                        tmp2 = {}
                        for row in pre:
                                over = row[3].split('.')[0]
                                if over not in tmp2:
                                        tmp2[over] = 1
                                else:
                                        tmp2[over] += 1
                        for k in tmp2:
                                if tmp2[k] == quantity:
                                        ans.append(k)
                if question[3] == 1:
                        tmp2 = {}
                        for row in pre:
                                if row[1] not in tmp2:
                                        tmp2[row[1]] = 1
                                else:
                                        tmp2[row[1]] += 1
                        for k in tmp2:
                                if tmp2[k] == quantity:
                                        ans.append(k)        
        return ans


def gohere1(ccc):
	if ccc<5:
		ccc=5
	if ccc==5:
		ccc=4




def goto(a,b):
	inpu=4
	if a<b:
		gohere1(inpu)
	elif a==b:
		gohere2(inpu)
	else:
		return

def solve_pre_bowlers(data,players,tempx):

        def verify(var,tempx):
                if tempx == 5 and var == 'W':
                        return 1
                if tempx == 6 and var == 'N':
                        return 1
                return 0

        toreturn= []
        for name in players:
                temp_str = data.split(',')
                for i in range(0,len(temp_str)-1):
                        dist= temp_str[i]
                        if str(name.split()[-1])+' to' in dist:
                                string = temp_str[i+1]
                                if 'no ball' in string:
                                        var = 'N'
                                        num = int(string.split()[0])
                                elif 'wide' in string:
                                        var = 'W'
                                        num = int(string.split()[0])
                                else:
                                        var = 'Z'
                                if verify(var,tempx):
                                        temp = []
                                        temp.append(name)
                                        temp.append(dist.split()[-1])
                                        temp.append(dist.split('\n')[-2])
                                        temp.append(var)
                                        temp.append(num)
                                        toreturn.append(tmp)
        return ans

def solve_for_bowlers(pre,players,quantity,question):
        toreturn= []
	goto(3,4)
        if quantity == -1:
                if len(players) == 1:
                        tempa = {}
                        for row in pre:
                                over = row[2].split('.')[0]
                                if over not in tempa:
                                        tempa[over] = row[4]
                                else:
                                        tempa[over] += row[4]


			goto(3,4)
                        maximum = 0
                        for key in tempa:
                                if tempa[key] > maximum:
                                        maximum = tempa[key]
                        for key in tempa:
                                if tempa[key] == maximum:
                                         toreturn.append([players[0],key,tempa[key]])
                else:
                        tmp = {}
                        for row in pre:
                                if row[0] not in tmp:
                                        tmp[row[0]] = row[4]
                                else:
                                        tmp[row[0]] += row[4]
                        maximum = 0
                        for key in tmp:
                                if tmp[key] > maximum:
                                        maximum = tmp[key]
                        for key in tmp:
                                if tmp[key] == maximum:
                                         toreturn.append([key,tmp[key]])
        elif quantity == 0:
                return pre
        else:
                tmp = {}
                for row in pre:
                        if row[0] not in tmp:
                                tmp[row[0]] = row[4]
                        else:
                                tmp[row[0]] += row[4]
                for key in tmp:
                        if tmp[key] == quantity:
                                toreturn.append(key)                
        return toreturn

def dismissed(data,players,over,question):
        ans=[]
        if over == -1:
		for key in players:
                	name = key.split()[-1]
                	temp_str = data.split(',')
                	for i in range(0,len(temp_str)):
                        	part = temp_str[i]
                        	if 'to '+str(name) in part:
                                	if 'OUT' in temp_str[i+1]:
						if question[1] == 1:
							t1=part.split('\n')[-2]
                                        		ans.append(t1)
						else:
							t2=part.split()[-3]
							ans.append(t2)
        else:
                temp_str = data.split(',')
                for i in range(0,len(temp_str)):
                        part = temp_str[i]
                        if str(over)+'.' in part:
                                if 'OUT' in temp_str[i+1]:
                                        ans.append(part.split()[-1])
        return ans

def wicket_taking_bowler(data,players,over):
        toreturn=[]
	for k in players:
		tempname = k.split()[-1]
        	temp_str = data.split(',')
        	for i in range(0,len(temp_str)):
                	part = temp_str[i]
                	if 'to '+str(tempname) in part:
                        	if 'OUT' in temp_str[i+1]:
                                	toreturn.append(part.split()[-3])
        return toreturn









def extractdata(fname):
        fp=open(fname, 'r')
	return fp.read()

def parse_for_over(x,over_no):
        if over_no is -1:
                return x
        e1='\n'+str(over_no)+'.1\n'
        e2= '\n'+str(over_no+1)+'.1\n'
        i1=x.find(e1)
        i2=x.find(e2)
        return x[i1+1:i2+1]
             

def obtain_solution(match,players,over,flags,quantity,question):
        n1=kiwi_commentary[match]
        n2=in_commentary[match]

        s1=extractdata(n1)
        s2=extractdata(n2)
        
        s1=parse_for_over(s1,over)
        s2=parse_for_over(s2,over)
        data=s1+s2
        ans=[]
        if len(players)==0:
                players=all_names
        for i in range(7):
                if flags[i]==1:
                        if i<=3:
                                pre=solve_pre_batsmen(data,players,i)
                                ans.append(solve_for_batsmen(pre,players,quantity[i],question))
                        if i>=5 and i<=6:
                                pre = solve_pre_bowlers(data,players,i)
                                ans.append(solve_for_bowlers(pre,players,quantity[i],question))
                        if i==4:
                                ans.append( dismissed(data,players,over,question) )
        if question[2] == 1:
                ans.append(wicket_taking_bowler(data,players,over))
        return ans

def main():
        query=raw_input()
        over_no = find_specific_over_no(query)
        match=findmatch(query)
        flags, quantity = parse_for_query(query)
        player_names= parse_for_players(query)
        question=parse_for_questions(query)
        solution=obtain_solution(match,player_names,over_no,flags,quantity,question)
	print "Answer to the given query is as follows:"
	ite=1
	for i in solution:
		for j in i:
			print ite,
			print ").",
			print j
			ite=ite+1
if __name__ == '__main__':
        main()        
