# Batsmen evaluation function
def solve_desc_batsmen(data,names,idx):

        def check(num,idx):
                if idx == 0 or idx == 1:
                        if num == idx + 1:
                                return 1
                if idx == 2 or idx == 3:
                        if num == 2*idx:
                                return 1
                return 0
        
        ans = []
        for name in names:
                count = 0
                text = data.split(',')
                for i in range(0,len(text)-1):
                        part = text[i]
                        if 'to '+str(name.split()[-1]) in part and name != 'I Sharma':
                                string = text[i+1].split()[0]
                                if string == 'SIX':
                                        num = 6
                                elif string == 'FOUR':
                                        num = 4
                                elif string == '1' or string == '2':
                                        num = int(string)
                                else:
                                        num = -1
                                if check(num,idx):
                                        tmp = []
                                        tmp.append(part.split()[-3])
                                        tmp.append(name)
                                        tmp.append(num)
                                        tmp.append(part.split('\n')[-2])
                                        ans.append(tmp)
        return ans

def solve_ques_batsmen(initial,names,quantity,question):
        ans = []
	print "Asdasd"
        if quantity == 0:
                if question[0] == 1 or question[1] == 1 or question[4] == 1:
                        for row in initial:
                                tmp  = []
                                if question[4] == 1:
                                        tmp.append(row[0])
                                tmp.append(row[1])
                                tmp.append(row[2])
                                if question[0] == 1:
                                        tmp.append(row[3].split('.')[1])
                                if question[1] == 1:
                                        tmp.append(row[3].split('.')[0])
                                if tmp not in ans:
                                        ans.append(tmp)
                else:
                        ans = initial 
        elif quantity == -1:
		print "sdasd"
                if question[3] == 1:
                        tmp = {}
                        for row in initial:
				print row
                                if row[1] not in tmp.keys():
                                        tmp[row[1]] = str(1)
                                else:
                                        tmp[row[1]] += str(1)
                        maximum = 0
                        for key in tmp:
                                if tmp[key] > maximum:
                                        maximum = tmp[key]
                                        name = key
                        ans.append([name,tmp[name]])
                else:
                        if question[4] == 1:
                                tmp = {}
                                for row in initial:
                                        if row[0] not in tmp:
                                                tmp[row[0]] = 1
                                        else:
                                                tmp[row[0]] += 1
                                maximum = 0
                                for key in tmp:
                                        if tmp[key] > maximum:
                                                maximum = tmp[key]
                                for key in tmp:
                                        if maximum == tmp[key]:
                                                ans.append([names[0],key,tmp[key]])
                        if question[1] == 1:
                                tmp = {}
                                for row in initial:
                                        key = row[3].split('.')[0]
                                        if key not in tmp:
                                                tmp[key] = 1
                                        else:
                                                tmp[key] += 1
                                maximum = 0
                                for key in tmp:
                                        if tmp[key] > maximum:
                                                maximum = tmp[key]
                                for key in tmp:
                                        if maximum == tmp[key]:
                                                ans.append([names[0],key,tmp[key]])
        else:
                tmp = {}
                if question[4] == 1:
                        tmp2 = {}
                        for row in initial:
                                if row[0] not in tmp2:
                                        tmp2[row[0]] = 1
                                else:
                                        tmp2[row[0]] += 1
                        for k in tmp2:
                                if tmp2[k] == quantity:
                                        ans.append(k)
                if question[1] == 1:
                        tmp2 = {}
                        for row in initial:
                                over = row[3].split('.')[0]
                                if over not in tmp2:
                                        tmp2[over] = 1
                                else:
                                        tmp2[over] += 1
                        for k in tmp2:
                                if tmp2[k] == quantity:
                                        ans.append(k)
                if question[3] == 1:
                        tmp2 = {}
                        for row in initial:
                                if row[1] not in tmp2:
                                        tmp2[row[1]] = 1
                                else:
                                        tmp2[row[1]] += 1
                        for k in tmp2:
                                if tmp2[k] == quantity:
                                        ans.append(k)        
        return ans
