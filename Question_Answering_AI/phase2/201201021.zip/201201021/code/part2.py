import re
import nltk	
import sys
def parse_for_mom(mom):
    toreturn = []
    for i in mom:
        toreturn.append(i)
    return toreturn 
def parse_for_six_fours(bat):
    toreturn = []
    for i in bat:
        if(float(bat[i][5])>float(bat[i][4])):
            toreturn.append(i)
    return toreturn
def parse_for_wonby(mom,wonby,ind,nz):
    toreturn = []
    for i in wonby:
        if(i=="India"):
            for j in ind:
                toreturn.append(j)
        elif(i=="New Zealand"):
            for j in nz:
                toreturn.append(j)
    return toreturn
def parse_for_zero(bat):
    toreturn = []
    for i in bat:
	temp=float(bat[i][1])
        if(temp==0):
            toreturn.append(i)
    return toreturn 
def parse_for_lostby(wonby,india,nz):
    toreturn = []
    for i in wonby:
        if(i=="New Zealand"):
            for j in india:
                toreturn.append(j)
        elif(i=="India"):
            for j in nz: 
                toreturn.append(j)
    return toreturn
def parse_for_greater_sr(bat,num):
    toreturn = []
    for i in bat:
        if(float(bat[i][6])>num):
            toreturn.append(i)
    return toreturn 
def parse_for_boundary(bat):
    toreturn = []
    for i in bat:
        if(float(bat[i][4])>0 or float(bat[i][5])>0):
            toreturn.append(i)
    return toreturn
def parse_for_runs(bat,runs):
    toreturn = []
    for i in bat:
        if(float(bat[i][1])>runs):
            toreturn.append(i)
    return toreturn 
def parse_for_rightleft(india,nz):
    toreturnright=[]
    toreturnleft=[]
    for i in india:
        if(india[i][6]):
            if(india[i][6][0]!='L'):
                toreturnright.append(i)
            else:
                toreturnleft.append(i)
        else:
                toreturnleft.append(i)
    for i in nz: 
        if(nz[i][6]):
            if(nz[i][6][0]!='L'):
                toreturnright.append(i)
            else:
                toreturnleft.append(i)
        else:
                toreturnleft.append(i)
    return toreturnleft,toreturnright
def parse_for_lstrike(bat,num):
    toreturn = []
    for i in bat:
        if(float(bat[i][6])<num):
            toreturn.append(i)
    return toreturn 
def parse_for_wickets(bowl):
    toreturn = []
    for i in bowl:
        if(float(bowl[i][3])>0):
            toreturn.append(i)
    return toreturn
def parse_for_overs(bowl,minovers):
    toreturn = []
    for i in bowl:
        if(float(bowl[i][0])>minovers):
            toreturn.append(i)
    return toreturn 
def parse_for_zero_wickets(bowl):
    toreturn = []
    for i in bowl:
        if(float(bowl[i][3])==0):
            toreturn.append(i)
    return toreturn
def parse_for_eco(bowl,eco):
    toreturn = []
    for i in bowl:
        if(float(bowl[i][4])>eco):
            toreturn.append(i)
    return toreturn 
def parse_for_more(bowl,india,nz):
    toreturn = []
    for i in bowl:
        for j in bowl:
            if(j!=i):
                if(float(bowl[i][3])>float(bowl[j][3])):
                    temp=[i,j]
                    toreturn.append(temp)
    return toreturn
def parse_for_age(india,nz,age):
    toreturn=[]
    for i in india:
        if(float(india[i][2].split(' ')[0])<age):
            toreturn.append(i)
    for i in nz: 
        if(float(nz[i][2].split(' ')[0])<age):
            toreturn.append(i)
    return toreturn




def generate_and_solve_query(mom, bat,bowl, winteam,india,nz,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh):
    c1 = parse_for_mom(mom)
    c2 = parse_for_wonby(mom,winteam,india,nz)
    c3 =parse_for_zero(bat)
    c4 =parse_for_lostby(winteam,india,nz)
    mapping = {}
    ctr = 0
    for i in india:
        i=i.split(' ')[1]
        if i not in mapping:
            mapping[i] = 'r' + str(ctr)
            ctr += 1
    for i in nz:
        i=i.split(' ')[1]
        if i not in mapping:
            mapping[i] = 'r' + str(ctr)
            ctr += 1
    temp_strin1 = ''
    for i in mapping:
        temp_strin1 += i + ' => ' + mapping[i] + '\n'
    temp_strin2 = 'mom => {'
    for i in c1:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c1)):
        temp_strin2 = temp_strin2[:-1]  
    temp_strin2 += '} \n'
    temp_strin3 = 'wonby => {'
    for i in c2:
        i=i.split(' ')[1]
        temp_strin3 += mapping[i] +  ','
    if(len(c2)):
        temp_strin3 = temp_strin3[:-1]  
    temp_strin3 += '} \n'
    
    v = temp_strin1 + temp_strin2 + temp_strin3
    
    temp_strin2 = 'duck => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c3)):
        temp_strin2 = temp_strin2[:-1] 
    temp_strin2 += '} \n'
    temp_strin3 = 'lostby => {'
    for i in c4:
        i=i.split(' ')[1]
        temp_strin3 += mapping[i] +  ','
    if(len(c4)):
        temp_strin3 = temp_strin3[:-1]  
    temp_strin3 += '} \n'
    v = v + temp_strin2 + temp_strin3
    
    c3=parse_for_greater_sr(bat,sr_greater)
    c4=parse_for_six_fours(bat)
    
    temp_strin2 = 'sr_greater => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c3)):
        temp_strin2 = temp_strin2[:-1]  
    temp_strin2 += '} \n'
    
    temp_strin3 = 'six_greater_fours => {'
    for i in c4:
        i=i.split(' ')[1]
        temp_strin3 += mapping[i] +  ','
    if(len(c4)):
        temp_strin3 = temp_strin3[:-1]  
    temp_strin3 += '} \n'

    v = v + temp_strin2 + temp_strin3
    
    c3=parse_for_lstrike(bat,sr_smaller)
    c4=parse_for_boundary(bat)
    
    temp_strin2 = 'sr_less => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c3)):
        temp_strin2 = temp_strin2[:-1]  
    temp_strin2 += '} \n'
    
    temp_strin3 = 'boundary => {'
    for i in c4:
        i=i.split(' ')[1]
        temp_strin3 += mapping[i] +  ','
    if(len(c4)):
        temp_strin3 = temp_strin3[:-1]  #removing the extra "," character
    temp_strin3 += '} \n'

    v = v + temp_strin2 + temp_strin3
    
    c3=parse_for_runs(bat,runs_greater)
    c4=parse_for_wickets(bowl)
    
    temp_strin2 = 'runsgt => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c3)):
        temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
    temp_strin2 += '} \n'
    
    temp_strin3 = 'wicketsgt0 => {'
    for i in c4:
        i=i.split(' ')[1]
        temp_strin3 += mapping[i] +  ','
    if(len(c4)):
        temp_strin3 = temp_strin3[:-1]  #removing the extra "," character
    temp_strin3 += '} \n'

    v = v + temp_strin2 + temp_strin3
    
    c3=parse_for_overs(bowl,overs_greater)
    c4=parse_for_zero_wickets(bowl)
    
    temp_strin2 = 'over_greater => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c3)):
        temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
    temp_strin2 += '} \n'
    
    temp_strin3 = 'zerowickets => {'
    for i in c4:
        i=i.split(' ')[1]
        temp_strin3 += mapping[i] +  ','
    if(len(c4)):
        temp_strin3 = temp_strin3[:-1]  #removing the extra "," character
    temp_strin3 += '} \n'

    v = v + temp_strin2 + temp_strin3
    
    c3=parse_for_eco(bowl,eco_greater)
    temp_strin2 = 'eco_greater => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c3)):
        temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
    temp_strin2 += '} \n'
    v = v + temp_strin2   
    
    c3,c4=parse_for_rightleft(india,nz)
    c5=parse_for_more(bowl,india,nz)
    temp_strin2 = 'lhb => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','

    if(len(c3)):
        temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
    temp_strin2 += '} \n'

    temp_strin3 = 'rhb => {'
    for i in c4:
        i=i.split(' ')[1]
        temp_strin3 += mapping[i] +  ','
    if(len(c4)):
        temp_strin3 = temp_strin3[:-1]  #removing the extra "," character
    temp_strin3 += '} \n'
    temp_strin4 = 'amorelw => {'
    for i in c5:
        i[0]=i[0].split(' ')[1]
        i[1]=i[1].split(' ')[1]
        temp_strin4 += '('+mapping[i[0]]+','+mapping[i[1]]+')'  +  ','
    if(len(c5)):
        temp_strin4 = temp_strin4[:-1]  #removing the extra "," character
    temp_strin4 += '} \n'
    v = v + temp_strin2 + temp_strin3 + temp_strin4 
    c3=parse_for_age(india,nz,age_lesshresh)
    temp_strin2 = 'age_less => {'
    for i in c3:
        i=i.split(' ')[1]
        temp_strin2 += mapping[i] +  ','
    if(len(c3)):
        temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
    temp_strin2 += '} \n'
    v = v + temp_strin2
    return v

def goto(x,y):
	if x > y:
		greater = x
	else:
		greater = y
	while(True):
		if((greater % x == 0) and (greater % y == 0)):
			lcm = greater
			break
		greater += 1

	return lcm



def make_model_and_soluwer(v, query, dt, satisfiable):
    l=goto(1000,4)
    val = nltk.parse_valuation(v)
    dom = val.domain
    m = nltk.Model(dom, val)
    g = nltk.Assignment(dom, [])
    solu= m.evaluate(query, g)
    final={}
    final["solu"]=solu
    if satisfiable:

        l = nltk.LogicParser()
        c1 = l.parse(satisfiable)
        varnames =  m.satisfiers(c1, 'x', g)

        final_queries=[]
        for i in varnames:
            for p,q in dt.iteritems():   # naive method to get key given value, in a dictionary
                if q == i:
                    final_queries.append(p)
        final["final_queries"]=final_queries
        if(len(final_queries)==0):
            final["solu"]=False
    else:
        final["final_queries"]=[]
    return final

def simp2(d,input_query):
    if 'economy' in d['pres']:
        string=re.findall('economy.+?[0-9]+',input_query,re.IGNORECASE)[0]
        no=string.split()[-1]
        d['economy']=int(no)
        
    if 'years' in d['pres']:
        string=re.findall('[0-9]+ year',input_query,re.IGNORECASE)[0]
        no=string.split()[0]
        d['year']=int(no)
    if 'strike.+rate'in d['pres']:
        string=re.findall('strike.+rate.+?[0-9]+',input_query,re.IGNORECASE)[0]
        no=string.split()[-1]
        solu=re.findall('above|greater|more',string,re.IGNORECASE)
        if len(solu):
            d['sr_greater']=int(no);
        else:
            d['sr_less']=int(no)
    if 'bowled.+overs' in d['pres']:
        string=re.findall('bowled.+?[0-9]+',input_query,re.IGNORECASE)[0]
        no=string.split()[-1]
        d['over_greater']=int(no)

    return d



def simplify_query(input_query):
    d={}
    input_query=' '.join(input_query.split())
    string1=["for all innings" , "there exists a player" ,"for all matches", "there exists a match"]
    for i in string1:
        temp=re.findall(i,input_query,re.IGNORECASE)
	flag=0
        if len(temp):
	    flag=1
	if flag==1:
            d['quantifier']=i
	    break
    conjunct=["if.+then","is given to","contains","and", "consists of"]
    for i in conjunct:
        temp=re.findall(i,input_query,re.IGNORECASE)
	f2=0
        if len(temp):
            f2=1
	if f2==1:
            d['conjunct']=i

    goto(400,100)
    pres=['a boundary','zero wicket','winning.+team','losing.+team','left handed bowler','right handed bowler','man of match|player of match','strike.+rate','economy','more.+six.+four','duck','bowled.+overs','years']
    pre=[]
    for i in pres:
        temp=re.findall(i,input_query,re.IGNORECASE)
	f3=0
        if len(temp):
	    f3=1
	if f3==1:
            pre.append(i)
            d['pres']=pre;
    d=simp2(d,input_query)

    return d


def add_to_dict(dictionary, fname):
    f = open(fname, 'r')
    for line in f:
        temp = line[:-1]
        temp = temp.split(',')
        a = temp[0]
        b = temp[1:]
        if a not in dictionary:
            dictionary[a] = b

def add_to_dict1(dictionary, fname,start,stop):
    f = open(fname, 'r')
    ctr=0
    for line in f:
        ctr=ctr+1
        temp = line[:-1]
        temp = temp.split(',')
        a = temp[0]
        b = temp[1:]
        if(start<=ctr and  ctr<=stop):
            if a not in dictionary:
                dictionary[a] = b


def add_to_profile(dictionary,fname):
    x=[]
    f=open(fname)
    for l in f:
        x.append(l.strip().split("\t"))
    for i in x:
        y=i[0]
        del(i[0])
        if y not in dictionary:
            dictionary[y]=i

def main():
    associated={}

    teamz=0
    temp1=1
    temp2=1
    temp3=1
    temp4=1
    temp5=1
    temp6=1
    indian_players={}
    kiwi_players={}
    data=[]
    bat11 = {}
    bowl11 = {}
    bats2_1 = {}
    bowl2_1 = {}
    bats3_1 = {}
    bowl31 = {}
    bats4_1 = {}
    bowl41 = {}
    bats5_1 = {}
    bowl51 = {}
    bat12 = {}
    bowl12 = {}
    bats2_2 = {}
    bowl2_2 = {}
    bats3_2 = {}
    bowl32 = {}
    bats4_2 = {}
    bowl42 = {}
    bats5_2 = {}
    bowl52 = {}
    mom1 = {}
    mom2 = {}
    mom3 = {}
    mom4 = {}
    mom5 = {}
    wonby1 = {}
    wonby2 = {}
    wonby3 = {}
    wonby4 = {}
    wonby5 = {}
    add_to_dict(bat11,'../dataset/match1/odi1_inn1_bat.txt')
    add_to_dict(bat12,'../dataset/match1/odi1_inn2_bat.txt')
    
    
    add_to_dict(bats2_1,'../dataset/match2/odi2_inn1_bat.txt')
    add_to_dict(bats2_2,'../dataset/match2/odi2_inn2_bat.txt')
    
    
    
    add_to_dict(bats3_1,'../dataset/match3/odi3_inn1_bat.txt')
    add_to_dict(bats3_2,'../dataset/match3/odi3_inn2_bat.txt')
    
    add_to_dict(bats4_1,'../dataset/match4/odi4_inn1_bat.txt')
    add_to_dict(bats4_2,'../dataset/match4/odi4_inn2_bat.txt')
    
    add_to_dict(bats5_1,'../dataset/match5/odi5_inn1_bat.txt')
    add_to_dict(bats5_2,'../dataset/match5/odi5_inn2_bat.txt')
    
    add_to_dict(bowl11,'../dataset/match1/odi1_inn1_bowl.txt')
    add_to_dict(bowl12,'../dataset/match1/odi1_inn2_bowl.txt')
    
    add_to_dict(bowl2_1,'../dataset/match2/odi2_inn1_bowl.txt')
    add_to_dict(bowl2_2,'../dataset/match2/odi2_inn2_bowl.txt')
    
    add_to_dict(bowl31,'../dataset/match3/odi3_inn1_bowl.txt')
    add_to_dict(bowl32,'../dataset/match3/odi3_inn2_bowl.txt')
    
    add_to_dict(bowl41,'../dataset/match4/odi4_inn1_bowl.txt')
    add_to_dict(bowl42,'../dataset/match4/odi4_inn2_bowl.txt')
    
    add_to_dict(bowl51,'../dataset/match5/odi5_inn1_bowl.txt')
    
    add_to_dict(bowl52,'../dataset/match5/odi5_inn2_bowl.txt')
    
    add_to_dict(mom1,'../dataset/match1/mom.txt')
    add_to_dict(mom2,'../dataset/match2/mom.txt')
    add_to_dict(mom3,'../dataset/match3/mom.txt')
    add_to_dict(mom4,'../dataset/match4/mom.txt')
    add_to_dict(mom5,'../dataset/match5/mom.txt')
    
    add_to_dict(wonby1,'../dataset/match1/wonby.txt')
    add_to_dict(wonby2,'../dataset/match2/wonby.txt')
    add_to_dict(wonby3,'../dataset/match3/wonby.txt')
    add_to_dict(wonby4,'../dataset/match4/wonby.txt')
    add_to_dict(wonby5,'../dataset/match5/wonby.txt')
    
    add_to_profile(indian_players, '../dataset/player_profile/indian_players_profile.txt')
    add_to_profile(kiwi_players,'../dataset/player_profile/nz_players_profile.txt')
    
    bat1=dict(bat11.items() + bat12.items())
    bat2=dict(bats2_1.items() + bats2_2.items())
    bat3=dict(bats3_1.items() + bats3_2.items())
    bat4=dict(bats4_1.items() + bats4_2.items())
    bat5=dict(bats5_1.items() + bats5_2.items())
    
    bowl1= dict(bowl11.items() + bowl12.items())
    bowl2= dict(bowl2_1.items() + bowl2_2.items())
    bowl3= dict(bowl31.items() + bowl32.items())
    bowl4= dict(bowl41.items() + bowl42.items())
    bowl5= dict(bowl51.items() + bowl52.items())
    
    
    input_query=raw_input()
    solu=simplify_query(input_query)
    conjunct=''
    tempquery=''
    mapping = {}
    ctr = 0
    for i in indian_players:
        i=i.split(' ')[1]
        if i not in mapping:
            mapping[i] = 'r' + str(ctr)
            ctr += 1
    for i in kiwi_players:
        i=i.split(' ')[1]
        if i not in mapping:
            mapping[i] = 'r' + str(ctr)
            ctr += 1

    if(solu['conjunct']=='if.+then'):
	    conjunct='->'
    elif(solu['conjunct']=='and'):
	    conjunct='&'
    elif(solu['conjunct']=='is given to'):
	    conjunct='&'
    elif(solu['conjunct']=='contains'):
        conjunct='&'
    elif(solu['conjunct']=='consists of'):
        conjunct='&'
    sr_greater=0
    sr_smaller=0
    runs_greater=0
    overs_greater=0
    eco_greater=0
    age_lesshresh=0
    
    
    if 'year' in solu:
        age_lesshresh=float(solu['year'])
    if 'sr_less' in solu:
        sr_smaller=float(solu['sr_less'])
    if 'sr_greater' in solu:
        sr_greater=float(solu['sr_greater'])
    if 'over_greater' in solu:
        overs_greater=float(solu['over_greater'])
    if 'economy' in solu:
        eco_greater=float(solu['economy'])

    goto(3,7)
    if(solu["quantifier"]=="for all matches" or solu["quantifier"]=="there exists a match"):
	match1=generate_and_solve_query(mom1, bat1,bowl1, wonby1,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        match2=generate_and_solve_query(mom2, bat2,bowl2, wonby2,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        match3=generate_and_solve_query(mom3, bat3,bowl3, wonby3,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        match4=generate_and_solve_query(mom4, bat4,bowl4, wonby4,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        match5=generate_and_solve_query(mom5, bat5,bowl5, wonby5,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        for i in solu['pres']:
            if 'left' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' lhb(x)'
                else:
                    tempquery= tempquery+ 'lhb(x)'
            if 'boundary' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' boundary(x)'
                else:
                    tempquery= tempquery+ 'boundary(x)'
            if 'wicket' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' zerowickets(x)'
                else:
                    tempquery= tempquery+ 'zerowickets(x)'
            if 'right' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' rhb(x)'
                else:
                    tempquery= tempquery+ 'rhb(x)'
            if 'six' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' six_greater_fours(x)'
                else:
                    tempquery= tempquery+ 'six_greater_fours(x)'
            if 'duck' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' duck(x)'
                else:
                    tempquery= tempquery+ 'duck(x)'
            if 'losing' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' lostby(x)'
                else:
                    tempquery= tempquery+ 'lostby(x)'
            if 'over' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' over_greater(x)'
                else:
                    tempquery= tempquery+ 'over_greater(x)'
            if 'winning' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' wonby(x)'
                else:
                    tempquery= tempquery+ 'wonby(x)'
            if 'man of match' in i:				    
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' mom(x)'
                else:
                    tempquery= tempquery+ 'mom(x)'
            if 'year' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' age_less(x)'
                else:
                    tempquery= tempquery+ 'age_less(x)'
            if 'strike' in i:
                temp=''
                if 'sr_greater' in solu:
                    temp ='sr_greater(x)'
                else:
                    temp='sr_less(x)'
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' ' + temp
                else:
                    tempquery= tempquery+ temp
            if 'economy' in i:
                temp='eco_greater(x)'
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' ' + temp
                else:
                    tempquery= tempquery+ temp

        final_query=tempquery
        tempquery= 'exists x ' + '( '+ tempquery+' )'
        final1=make_model_and_soluwer(match1, tempquery, mapping,final_query)
        final2=make_model_and_soluwer(match2, tempquery, mapping,final_query)
        final3=make_model_and_soluwer(match3, tempquery, mapping,final_query)
        final4=make_model_and_soluwer(match4, tempquery, mapping,final_query)
        final5=make_model_and_soluwer(match5, tempquery, mapping,final_query)
        if(solu["quantifier"]=="for all matches"):

            print (final1['solu'] and final2['solu'] and final3['solu'] and final4['solu'] and final5['solu'])
        else:
            print (final1['solu'] or final2['solu'] or final3['solu'] or final4['solu'] or final5['solu'])



    elif(solu["quantifier"]=="for all innings"):
        in1=generate_and_solve_query(mom1, bat11,bowl11, wonby1,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in2=generate_and_solve_query(mom2, bat12,bowl12, wonby2,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in3=generate_and_solve_query(mom3, bats2_1,bowl2_1, wonby3,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in4=generate_and_solve_query(mom4, bats2_2,bowl2_2, wonby4,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in5=generate_and_solve_query(mom5, bats3_1,bowl31, wonby5,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in6=generate_and_solve_query(mom5, bats3_2,bowl32, wonby5,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in7=generate_and_solve_query(mom5, bats4_1,bowl41, wonby5,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in8=generate_and_solve_query(mom5, bats4_2,bowl42, wonby5,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in9=generate_and_solve_query(mom5, bats5_1,bowl51, wonby5,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        in10=generate_and_solve_query(mom5, bats5_2,bowl52, wonby5,indian_players,kiwi_players,sr_greater,sr_smaller,runs_greater,overs_greater,eco_greater,age_lesshresh)
        for i in solu['pres']:
            if 'left' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' lhb(x)'
                else:
                    tempquery= tempquery+ 'lhb(x)'
            if 'wicket' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' zerowickets(x)'
                else:
                    tempquery= tempquery+ 'zerowickets(x)'
            if 'boundary' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' boundary(x)'
                else:
                    tempquery= tempquery+ 'boundary(x)'
            if 'six' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' six_greater_fours(x)'
                else:
                    tempquery= tempquery+ 'six_greater_fours(x)'
            if 'right' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' rhb(x)'
                else:
                    tempquery= tempquery+ 'rhb(x)'
            if 'losing' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' lostby(x)'
                else:
                    tempquery= tempquery+ 'lostby(x)'
            if 'duck' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' duck(x)'
                else:
                    tempquery= tempquery+ 'duck(x)'
            if 'winning' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery + ' '+ conjunct + ' wonby(x)'
                else:
                    tempquery= tempquery+ 'wonby(x)'
            if 'year' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' age_less(x)'
                else:
                    tempquery= tempquery+ 'age_less(x)'
            if 'man of match' in i:				    
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' mom(x)'
                else:
                    tempquery= tempquery+ 'mom(x)'
            if 'economy' in i:
                temp='eco_greater(x)'
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' ' + temp
                else:
                    tempquery= tempquery+ temp
            if 'over' in i:
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' over_greater(x)'
                else:
                    tempquery= tempquery+ 'over_greater(x)'
            if 'strike' in i:
                temp=''
                if 'sr_greater' in solu:
                    temp ='sr_greater(x)'
                else:
                    temp='sr_less(x)'
                if(len(tempquery)>0):
                    tempquery=tempquery +' '+ conjunct +' ' + temp
                else:
                    tempquery= tempquery+ temp

        final_query=tempquery
        tempquery= 'exists x ' + '( '+ tempquery+' )'
	fans=[]
        fans.append(make_model_and_soluwer(in1, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in2, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in3, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in4, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in5, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in6, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in7, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in8, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in9, tempquery, mapping,final_query))
        fans.append(make_model_and_soluwer(in10, tempquery, mapping,final_query))
	flagf=0
	for i in range(len(fans)):
			if fans[i]==False:
				flagf=1
	if flagf==0:
		print "True"
	else:
		print "False"


if __name__ == "__main__":
    main()
