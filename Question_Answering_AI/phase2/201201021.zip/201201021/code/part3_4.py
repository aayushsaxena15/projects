import sys
from nltk.corpus import wordnet 


def get(tempstring):
	temp = []
	for k in wordnet.synsets(tempstring):
		for l in k.lemma_names:
			temp.append(l)
	return temp

def solve(final,match_number):
	tempstring=''
	kiwi=""
	fp=open("../dataset/player_profile/nz_players_profile.txt")
	kiwi=fp.read()
	fp2=open("../dataset/player_profile/indian_players_profile.txt") 
	india=fp2.read() 
	kiwi=kiwi+india 
	kiwi.upper() 
	if(match_number==1 or match_number==-1):
		fp3=open("../dataset/match1/commentary_in.txt","r") 
		for line in fp3:
			tempstring+=line 
		fp4=open("../dataset/match1/commentary_nz.txt","r") 
		for line in fp4:
			tempstring+=line 
	if(match_number==2 or match_number==-1):
		fp5=open("../dataset/match2/commentary_in.txt","r") 
		for line in fp5:
			tempstring+=line 
		fp6=open("../dataset/match2/commentary_nz.txt","r") 
		for line in fp6:
			tempstring+=line 
	if(match_number==3 or match_number==-1):
		fp7=open("../dataset/match3/commentary_in.txt","r") 
		for line in fp7:
			tempstring+=line 
		fp8=open("../dataset/match3/commentary_nz.txt","r") 
		for line in fp8:
			tempstring+=line 
	if(match_number==4 or match_number==-1):
		fp9=open("../dataset/match4/commentary_in.txt","r") 
		for line in fp9:
			tempstring+=line 
		fp10=open("../dataset/match4/commentary_nz.txt","r") 
		for line in fp10:
			tempstring+=line 
	if(match_number==5 or match_number==-1):
		fp11=open("../dataset/match5/commentary_in.txt","r") 
		for line in fp11:
			tempstring+=line 
		x=open("../dataset/match5/commentary_nz.txt","r") 
		for line in x:
			tempstring+=line 
	x=tempstring.split('\n') 
	currtempstring=""
	ctrmax=0 
	for i in x:
		ctr=0
		ctr2=0
		for j in final:
			flag=0
			f=0
			for l in j:
				if(l>'a' and l<'z'):
					flag=1 
			if j.upper() in i.upper():
				f=1 
			if(flag==0):
				look=get(j) 
				for q in look:
					if q.upper() in i.upper():
						f=2 
			if(f>0 and (j.upper() in kiwi.upper())==True):
				f=f+2
			ctr=ctr+f 
		for j in range(len(final)-1):
			flag1=0
			for k in final[j]:
				if(k>'a' and k<'z'):
					flag1=1 
			look1=[]
			if(flag1==0):
				look1=get(final[j]) 
			look1.append(final[j]) 
			flag2=0
			for k in final[j+1]:
				if(k>'a' and k<'z'):
					flag2=1 
			look2=[]
			if(flag2==0):
				look2=get(final[j+1]) 
			look2.append(final[j+1]) 
			for n in look1:
				for m in look2:
					w=n+' '+m 
				if w.upper() in i.upper():
					f=max(f,flag1+flag2+1) 
			if(f>0 and (final[j].upper() in kiwi.upper())==True):
				f=f+1
			if(f>0 and (final[j+1].upper() in kiwi.upper())==True):
				f=f+1
			ctr2=ctr2+f 
		counte=ctr2*10+ctr*4 
		if(ctrmax<counte):
			ctrmax=counte 
			currtempstring=i 
	i=currtempstring
	for z in range(1):
		for j in final:
			flag=0
			f=0
			for k in j:
				if(k>'a' and k<'z'):
					flag=1 
			if j in i:
				f=1 
			if(flag==0):
				look=get(j) 
				for q in j:
					if q in i:
						f=2 
			ctr=ctr+f 
	for e in range(1):
		for j in range(len(final)-1):
			flag1=0
			for k in final[j]:
				if(k>'a' and k<'z'):
					flag1=1 
			look1=[]
			if(flag1==0):
				look1=get(final[j]) 
			look1.append(final[j]) 
			flag2=0
			for k in final[j+1]:
				if(k>'a' and k<'z'):
					flag2=1 
			look2=[]
			if(flag2==0):
				look2=get(final[j+1]) 
			look2.append(final[j+1]) 
			for n in look1:
				for m in look2:
					w=n+' '+m
				if w in i:
					f=flag1+flag2+1
			ctr2=ctr2+f
	return currtempstring
def main():
	dic=[]
	inp=raw_input()
	inp=inp[:-1]
	dic=inp.split()
	match_number=-1
	if (("match 1" in inp)) or (("first match" in inp)):
		match_number=1
	if (("match 2" in inp)) or (("second match" in inp)):
		match_number=2
	if (("match 3" in inp)) or (("third match" in inp)):
		match_number=3
	if(("match 4" in inp)) or (("fourth match" in inp)):
		match_number=4
	if(("match 5" in inp)) or (("fifth match" in inp)):
		match_number=5
	flagno=0
	for i in dic:
		flag=0
		for j in i:
			if(j<'A' or j>'Z'):
				flag=1
		if( flag==1 and len(i)<=4):
			dic[flagno]="invalid"
		if(i=="match" ):
			dic[flagno]="invalid"
		flagno=flagno+1
	final=[]
	for i in dic:
		if(i!="invalid"):
			final.append(i)
	solution=solve(final,match_number)
	print solution 


if __name__=='__main__':
	main()
