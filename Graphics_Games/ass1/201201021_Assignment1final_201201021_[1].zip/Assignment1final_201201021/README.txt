For compiling the source code, type

g++ Assignment1_final.cpp -lglut -lGL -lGLU  on the terminal where Assignment1_final.cpp is the name of the program.

Then type

 ./a.out to execute the program.


input.txt contains the arguments:

first argument- box length and height ( square box)
second argument- difficulty level (integer)
third argument-  x co-ordinate of red basket
fourth argument- x co-ordinate of green basket
fifth argument- x co-ordinate of canon
