#include <iostream>
#include <cmath>
#include <GL/glut.h>
#include <time.h>

using namespace std;

#define PI 3.141592653589
#define DEG2RAD(deg) (deg * PI / 180)

float p1_x,p1_y,p2_x,p2_y;
float theta = 90.0f;
float beamvel=1.0f;
float beam_y=-1.6f,beam_x;

float box_len = 4.0f;

float red_x=-1.5f;
float red_y=-1.8f;

float green_x=1.5f;
float green_y=-1.8f;
float canon_x=0.0f;
float canon_y=-1.8f;

int flagc=0,flagr=0,flagg=0;
float l=0.5f;
int index=0;
int flagbeam=0;float rad=DEG2RAD(theta);
time_t prev=time(NULL);
float spider_x,spider_y=1.8f;
float spidervel=0.0001f;
void drawScene();
void update(int value);
void drawBox(float len);
void initRendering();
void handleResize(int w, int h);
void handleKeypress1(unsigned char key, int x, int y);
void handleKeypress2(int key, int x, int y);
void handleMouseclick(int button, int state, int x, int y);


typedef struct spiders
{
	float x,y,vel;
	int c,cond,in;
}spiders;
spiders s[1000000];


typedef struct laser
{
	float x,y,angle,l;
}laser;
laser beams[10000];
int beamind=0;
void update2(int value)
{
	float a,d;
	a=(float)((rand()%3400-1700))/1000;
	s[index].x=a;
	s[index].y=1.8f;
	s[index].vel=0.003f;
	int color=rand()%3;
	s[index++].c=color;

	glutTimerFunc(1000, update2, 0);//update func is called after 10 msec

}

int main(int argc, char **argv) {
	for(int i=0;i<index;i++)
		s[i].in=0;

	// Initialize GLUT
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	int w = glutGet(GLUT_SCREEN_WIDTH);
	int h = glutGet(GLUT_SCREEN_HEIGHT);
	int windowWidth = w;
	int windowHeight = h;

	glutInitWindowSize(windowWidth, windowHeight);
	glutInitWindowPosition((w - windowWidth) / 2, (h - windowHeight) / 2);

	glutCreateWindow("Arachnophobia");  // Setup the window
	initRendering(); //draw the scene
	// Register callbacks
	glutDisplayFunc(drawScene);// when u draw , it is called...most important
	glutIdleFunc(drawScene);// when reendering on the current frame is done ....animation
	glutKeyboardFunc(handleKeypress1);//when u press keyboard or mouse...
	glutSpecialFunc(handleKeypress2);//handles arrow keys etc
	glutMouseFunc(handleMouseclick);
	glutReshapeFunc(handleResize); //when window is reshaped
	glutTimerFunc(10, update, 0);//update func is called after 10 msec
	glutTimerFunc(1000, update2, 0);//update func is called after 10 msec

	glutMainLoop();
	return 0;
}
// Function to draw objects on the screen
void drawScene() {   //most important
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  
	glMatrixMode(GL_MODELVIEW); 
	glLoadIdentity();  
	glPushMatrix(); 

	// Draw Box   // f means float
	glTranslatef(0.0f, 0.0f, -5.0f);  // into the screen...drawing at 0,0,-5 initially
	glColor3f(0.0f, 0.0f, 1.0f);  // rgb arguments 
	drawBox(box_len);

	glPushMatrix();
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);//not filled with color...for main screen
	glBegin(GL_QUADS);//making quadrilaterals
	glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2f(red_x-0.2,red_y-0.1);//first coordinate
	glVertex2f(red_x+0.2, red_y-0.1);//second
	glVertex2f(red_x+0.2,red_y+0.4);//third
	glVertex2f(red_x-0.2,red_y+0.4);//fourth
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);//not filled with color...for main screen
	glBegin(GL_QUADS);//making quadrilaterals
	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(green_x-0.2,green_y-0.1);//first coordinate
	glVertex2f(green_x+0.2,green_y -0.1);//second
	glVertex2f(green_x+0.2,green_y+0.4);//third
	glVertex2f(green_x-0.2,green_y+0.4);//fourth
	glEnd();
	glPopMatrix();
	
	glPushMatrix();
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);//not filled with color...for main screen
	glBegin(GL_QUADS);//making quadrilaterals
	glColor3f(0.0, 0.0, 1.0);
	glVertex3f(canon_x-0.3,canon_y-0.1,0.0);
	glVertex3f(canon_x+0.3, canon_y-0.1, 0);
	glVertex3f(canon_x+0.3, canon_y+0.2, 0);
	glVertex3f(canon_x-0.3, canon_y+0.2, 0);
	glEnd();
	glPopMatrix();



	glPushMatrix();
	for(int i=0;i<beamind;i++)
	{
		glLineWidth(2.5);
		glColor3f(0.0, 0.0, 1.0);
		glBegin(GL_LINES);
		glVertex3f(beams[i].x, beams[i].y, 0.0);
		glVertex3f(beams[i].x+(beams[i].l)*cos(DEG2RAD(beams[i].angle)),beams[i].y+(beams[i].l)*sin(DEG2RAD(beams[i].angle)), 0);
	}
	glEnd();
	glPopMatrix();


	glPushMatrix();
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);//not filled with color...for main screen
	glBegin(GL_QUADS);//making quadrilaterals
	for(int i=0;i<index;i++)
	{
		if(s[i].in!=1)
		{
		if(s[i].c==0)
			glColor3f(1.0f, 0.0f, 0.0f);
		else if(s[i].c==1)
			glColor3f(0.0f, 1.0f, 0.0f);
		else
			glColor3f(0.0f, 0.0f, 0.0f);

		glVertex2f(s[i].x-0.1,s[i].y-0.1);//first coordinate
		glVertex2f(s[i].x+0.1,s[i].y-0.1);//second
		glVertex2f(s[i].x+0.1,s[i].y+0.1);//third
		glVertex2f(s[i].x-0.1,s[i].y+0.1);//fourth
		}
	}
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glLineWidth(2.5);
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
	glVertex3f(canon_x,canon_y,0.0);
	rad=DEG2RAD(theta);
	glVertex3f(canon_x+l*cos(rad), canon_y+l*sin(rad), 0);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glLineWidth(2.5);
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
	glVertex3f(-2, -1.7, 0.0);
	glVertex3f(2, -1.7, 0);
	glEnd();
	glPopMatrix();

	glPopMatrix();
	glutSwapBuffers();
}
// Function to handle all calculations in the scene
// updated evry 10 milliseconds
void update(int value) {

	for(int i=0;i<index;i++)
	{

		if(s[i].y-0.1<=-1.6&&s[i].x-0.1>=red_x-0.2&&s[i].x+0.1<=red_x+0.2&&s[i].cond!=1)
			s[i].in=1;
		if(s[i].y-0.1<=-1.6&&s[i].x-0.1>=green_x-0.2&&s[i].x+0.1<=green_x+0.2&&s[i].cond!=1)
			s[i].in=1;
	}
	
	for(int i=0;i<beamind;i++)
	{
		beams[i].x+=((0.05f)*cos(DEG2RAD(beams[i].angle)));
		beams[i].y+=((0.05f)*sin(DEG2RAD(beams[i].angle)));
	}
	for(int i=0;i<index;i++)
	{
		if(s[i].y>-1.9)
			s[i].y-=s[i].vel;
		else 
			s[i].cond=1;
	}


	glutTimerFunc(10, update, 0);
}

void drawBox(float len) {

	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);//not filled with color...for main screen
	glBegin(GL_QUADS);//making quadrilaterals
	glVertex2f(-len / 2, -len / 2);//first coordinate
	glVertex2f(len / 2, -len / 2);//second
	glVertex2f(len / 2, len / 2);//third
	glVertex2f(-len / 2, len / 2);//fourth
	glEnd();
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}


void initRendering() {

	glEnable(GL_DEPTH_TEST);        
	glEnable(GL_COLOR_MATERIAL);    
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);   
}

void handleResize(int w, int h) {  

	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION); 
	glLoadIdentity();
	gluPerspective(45.0f, (float)w / (float)h, 0.1f, 200.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void handleKeypress1(unsigned char key, int x, int y) {// keyboard
	if(key==' ')
	{
		time_t currtime=time(NULL);
		if(difftime(currtime,prev)>=1)
		{
		beams[beamind].x=canon_x;
		beams[beamind].y=canon_y;
		beams[beamind].angle=theta;
		beams[beamind++].l=0.5f;
		prev=currtime;
		}

	}

	if (key == 27) {
		exit(0);     // escape key is pressed
	}

	if(key=='b')
	{
		flagc=1;
		flagr=0;
		flagg=0;
		glutSpecialFunc(handleKeypress2);//handles arrow keys etc
	}
	if(key=='r')
	{
		flagr=1;
		flagc=0;
		flagg=0;
		glutSpecialFunc(handleKeypress2);//handles arrow keys etc
	}
	if(key=='g')
	{
		flagc=0;
		flagr=0;
		flagg=1;
		glutSpecialFunc(handleKeypress2);//handles arrow keys etc
	}

}

void handleKeypress2(int key, int x, int y) {//arrow keys

	if (key == GLUT_KEY_LEFT&&flagc==1&&canon_x>-1.7)
	{
	/*	float max=-2.0f;
		for(int i=0;i<index;i++)
		{
			if(s[i].cond==1)
			{
				cout<<s[i].y<<endl;
				if(s[i].x>=max)
					max=s[i].x;
			}
		}
		if(canon_x>max)*/
			canon_x-=0.1;
	}
	if (key == GLUT_KEY_RIGHT&&flagc==1&&canon_x<1.7)
	{
	/*	float min=2.0f;
		for(int i=0;i<index;i++)
		{
			if(s[i].cond==1)
			{
				cout<<s[i].y<<endl;
				if(s[i].x<=min)
					min=s[i].x;
			}
		}
		if(canon_x<min)*/
		canon_x+=0.1;
	}
	if (key == GLUT_KEY_LEFT&&flagr==1&&red_x>-1.8)
		red_x-=0.1;
	if (key == GLUT_KEY_RIGHT&&flagr==1&&red_x<1.8)
		red_x+=0.1;
	if (key == GLUT_KEY_LEFT&&flagg==1&&green_x>-1.8)
		green_x-=0.1;
	if (key == GLUT_KEY_RIGHT&&flagg==1&&green_x<1.8)
		green_x+=0.1;
	if (key == GLUT_KEY_UP &&flagc==1)
		theta+=15;
	if (key == GLUT_KEY_DOWN&&flagc==1)
		theta-=15;
}


void handleMouseclick(int button, int state, int x, int y)
{

	if (state == GLUT_DOWN)//down==press..........up=releasing
	{
		if (button == GLUT_LEFT_BUTTON)
			theta += 15;
		else if (button == GLUT_RIGHT_BUTTON)
			theta -=15;
	}
}
