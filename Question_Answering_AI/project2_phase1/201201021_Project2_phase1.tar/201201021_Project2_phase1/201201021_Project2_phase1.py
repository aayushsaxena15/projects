import nltk	
import sys
def add_to_dict(dictionary, fname):
	f = open(fname, 'r')
	for line in f:
		temp = line[:-1]
		temp = temp.split(',')
		a = temp[0]
		b = temp[1:]
		dictionary[a] = b
def add_to_dicttabseparated(dictionary, fname):
	f = open(fname, 'r')
	for line in f:
		temp = line[:-1]
		temp = temp.split('\t')
		a = temp[0]
		b = temp[1:]
		dictionary[a] = b
def add_to_listfinal(fname,lis):
	f = open(fname, 'r')
	for line in f:
		temp = line[:-1]
		temp = temp.split('\t')
		a = temp[0]
		b = temp[1:]
		lis.append(a)



def add_to_listtabseparated(player,profile):
	f = open(profile, 'r')
	for line in f:
		temp = line[:-1]
		temp = temp.split('\t')
		a = temp[0]
		age=temp[3].split(' ')
		if int(age[0])<26:
			player.append(a)
def parse_for_toss(toss1):
	toreturn=[]
	for i in toss1:
		toreturn.append(i)
	return toreturn
def add_to_listtabseparatedbowlers(lhb,rhb,profile):
	f = open(profile, 'r')
	for line in f:
		temp = line[:-1]
		temp = temp.split('\t')
		a = temp[0]
		style=temp[7].split('-')
		if style[0]=='Left':
			lhb.append(a)
		else:
			rhb.append(a)






def parse_for_sr(bat, num):
	toreturn = []
	for i in bat:
		temp = bat[i]
		k = float(temp[6])
		if k > num:
			toreturn.append(i)
	return  toreturn
def parse_for_mom(mom):
	toreturn=[]
	for i in mom:
	#	temp=mom[i]
	#	k=(temp[0])
		toreturn.append(i)
	return toreturn
def parse_for_wonby(wonby):
	toreturn=[]
	for i in wonby:
		toreturn.append(i)
	return toreturn
def parse_for_lostby(lostby):
	toreturn=[]
	for i in lostby:
		toreturn.append(i)
	return toreturn
def parse_for_six(bat, num):
	toreturn  = []
	for i in bat:
		temp = bat[i]
		k = int(temp[5])
		if k > num:
			toreturn.append(i)
	return toreturn
def parse_for_moresixes(bat):
	toreturn  = []
	for i in bat:
		temp = bat[i]
		k = int(temp[5])
		l=int(temp[4])
		if k > l:
			toreturn.append(i)
	return toreturn
def parse_for_zeroes(bat, num):
	toreturn  = []
	for i in bat:
		temp = bat[i]
		k = int(temp[1])
		if k == 0:
			toreturn.append(i)
	return toreturn
def parse_for_nonzero(bat, num):
	toreturn  = []
	for i in bat:
		temp = bat[i]
		k = int(temp[1])
		if k > 0:
			toreturn.append(i)
	return toreturn
def parse_for_out_on_zeroes(bat, num):
	toreturn  = []
	for i in bat:
		temp = bat[i]
		k = int(temp[1])
		if k == 0 and temp[0]!='not out':
			toreturn.append(i)
	return toreturn
def parse_for_hundred(bat, num):
	toreturn  = []
	for i in bat:
		temp = bat[i]
		k = int(temp[1])
		if k >= 100:
			toreturn.append(i)
	return toreturn
def parse_for_runs(bat, num):
	toreturn  = []
	for i in bat:
		temp = bat[i]
		k = int(temp[1])
		if k >= num:
			toreturn.append(i)
	return toreturn
def parse_for_wickets(bowl, num):
	toreturn  = []
	for i in bowl:
		temp = bowl[i]
		k = int(temp[3])
		if k == num:
			toreturn.append(i)
	return toreturn
def parse_for_economy(bowl, num):
	toreturn  = []
	for i in bowl:
		temp = bowl[i]
		k = float(temp[4])
		if k > num:
			toreturn.append(i)
	return toreturn
def parse_for_overs(bowl, num):
	toreturn  = []
	for i in bowl:
		temp = bowl[i]
		k = float(temp[0])
		if k >= num:
			toreturn.append(i)
	return toreturn
def calculatewickets(bowl1,lhb):
	leftw=0
	for i in bowl1:
		if i in lhb:
			leftw=leftw+int(bowl1[i][3])
	return leftw


def calculatewides(bowl1,sharma_wides,jadeja_wides):
	for i in bowl1:
		if i=='I Sharma':
			if len(bowl1[i])==6:
				if len(sharma_wides)==1:
					sharma_wides[0]=int(sharma_wides[0])+int(bowl1[i][5][1])
				else:
					sharma_wides.append(bowl1[i][5][1])
		elif i=='RA Jadeja':
			if len(bowl1[i])==6:
				if len(jadeja_wides)==1:
					jadeja_wides[0]=int(jadeja_wides[0])+int(bowl1[i][5][1])
				else:
					jadeja_wides.append(bowl1[i][5][1])
def calculatecatches(bat1,southee_caught,ryder_caught):
	for i in bat1:
		temp=bat1[i][0].split(' ')
		if temp[0]=='c' and temp[1]=='Southee':
			if len(southee_caught)==1:
				southee_caught[0]=int(southee_caught[0])+1
			else:
				southee_caught.append(1)
		elif temp[0]=='c' and temp[1]=='Ryder':
			if len(ryder_caught)==1:
				ryder_caught[0]=int(ryder_caught[0])+1
			else:
				ryder_caught.append(1)


def generate_and_solve_query1(mom, wonby,entree):
	c1 = parse_for_mom(mom)
	c2={}
	profile=''
	flag=0
	pp={}
	profile='./dataset/player_profile/nz_players_profile.txt'
	add_to_dicttabseparated(pp,profile)
	profile='./dataset/player_profile/indian_players_profile.txt'
	add_to_dicttabseparated(pp,profile)
	if wonby.keys()[0]=='New Zealand':
		profile='./dataset/player_profile/nz_players_profile.txt'
		add_to_dicttabseparated(c2,profile)
	elif wonby.keys()[0]=='India':
		profile='./dataset/player_profile/indian_players_profile.txt'
		add_to_dicttabseparated(c2,profile)
	else:
		return 'False'


	name_to_var = {}
	count = 0
	for i in pp:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'mom => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'wonby => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (mom(x) -> wonby(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('(mom(x) & (mom(x) -> wonby(x)))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
	
def generate_and_solve_query3(bats,entree):
	c1 = parse_for_sr(bats,200.0)
	c2 = parse_for_moresixes(bats)
	name_to_var = {}
	count = 0
	for i in bats:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'sr => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'moresixes => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'all x (sr(x) -> moresixes(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('(sr(x) & (sr(x)-> moresixes(x)))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query5(bats,bowl,entree):
	c1 = parse_for_runs(bats,50.0)
	c2 = parse_for_wickets(bowl,1)
	name_to_var = {}
	count = 0
	for i in bats:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	for i in bowl:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'runs => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'wickets => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (runs(x) -> wickets(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((runs(x)) & (runs(x) -> wickets(x)))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)

def generate_and_solve_query6(bowl,entree):
	c1 = parse_for_overs(bowl,7.0)
	c2 = parse_for_wickets(bowl,0)
	name_to_var = {}
	count = 0
	for i in bowl:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'overs => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'wickets => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (overs(x) -> wickets(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((overs(x)) & (overs(x) ->  wickets(x)))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query7(bowl,entree):
	c1 = parse_for_economy(bowl,8.0)
	c2 = parse_for_wickets(bowl,0)
	name_to_var = {}
	count = 0
	for i in bowl:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'economy => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'wickets => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (economy(x) & wickets(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((economy(x)) & wickets(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query2(bats,wonby,entree):
	c1 = parse_for_zeroes(bats,0)
	c2 = parse_for_wonby(wonby)
	c=''
	for i in wonby:
		c=i
	lost=[]
	if c=='New Zealand':
		lost.append('India')
		c2='India'
	elif c=='India':
		lost.append('New Zealand')
		c2='New Zealand'
	else:
		return
	if c2=='India':
		profile='./dataset/player_profile/indian_players_profile.txt'
	else:
		profile='./dataset/player_profile/nz_players_profile.txt'

	pp={}
	add_to_dicttabseparated(pp,profile)
	duckplayers=[]
	flag=0
	for key in pp.keys():
		for j in c1:
			if j==key:
				flag=1
				duckplayers.append(j)
	new1=[]
	if flag==1:
		if c2=='India':
			new1.append('India')
		elif c2=='New Zealand':
			new1.append('New Zealand')
	


		
	name_to_var = {}
	count = 0
	name_to_var['India']='1'
	name_to_var['New Zealand']='2'
	name_to_var['Tie']='3'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'lost => {'
	for i in lost:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'zeroes => {'
	for i in new1:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'all x (lost(x) -> zeroes(x))'
	if flag:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((lost(x)) & (lost(x) ->  zeroes(x)))')
		varnames =  m.satisfiers(c1, 'x', g)
		entree.append(duckplayers)
		return m.evaluate(query,g)
	
def parse_for_sr4(bats,k,pp):
	toreturn=[]
	for i in bats:
		if i in pp:
			if float(bats[i][6])<k:
				toreturn.append(i)
	return toreturn
def parse_for_boundary(bats,pp):
	toreturn=[]
	for i in bats:
		if i in pp:
			if int(bats[i][4])>=1:
				toreturn.append(i)
	return toreturn
def generate_and_solve_query4(bats,wonby,entree):
	c=''
	for i in wonby:
		c=i
	lost=[]
	if c=='New Zealand':
		profile='./dataset/player_profile/nz_players_profile.txt'
	elif c=='India':
		profile='./dataset/player_profile/indian_players_profile.txt'
	else:
		return

	pp={}
	add_to_dicttabseparated(pp,profile)
	c1 = parse_for_sr4(bats,100.0,pp)
	c2 = parse_for_boundary(bats,pp)
	
	name_to_var = {}
	count = 0
	for i in pp:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1


		
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'sr => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'boundary => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (sr(x) & boundary(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((sr(x)) & boundary(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query8(bats,wonby,entree):
	c1 = parse_for_hundred(bats,100)
	c2 = parse_for_wonby(wonby)
	c=''
	for i in wonby:
		c=i
	lost=[]
	if c=='New Zealand':
		lost.append('India')
		c2='India'
	elif c=='India':
		lost.append('New Zealand')
		c2='New Zealand'
	else:
		return
	if c2=='India':
		profile='./dataset/player_profile/indian_players_profile.txt'
	else:
		profile='./dataset/player_profile/nz_players_profile.txt'

	pp={}
	add_to_dicttabseparated(pp,profile)
	duckplayers=[]
	flag=0
	for key in pp.keys():
		for j in c1:
			if j==key:
				flag=1
				duckplayers.append(j)
	new1=[]
	if flag==1:
		if c2=='India':
			new1.append('India')
		elif c2=='New Zealand':
			new1.append('New Zealand')
	


		
	name_to_var = {}
	count = 0
	name_to_var['India']='1'
	name_to_var['New Zealand']='2'
	name_to_var['Tie']='3'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'lost => {'
	for i in lost:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'hundred => {'
	for i in new1:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (lost(x) -> hundred(x))'
	if flag:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('(lost(x) & ((lost(x)) -> hundred(x)))')
		varnames =  m.satisfiers(c1, 'x', g)
		entree.append(duckplayers)
		return m.evaluate(query,g)
def generate_and_solve_query9(bowl1,lhb,rhb,entree1):
	c1=[]
	c2=[]
	left=calculatewickets(bowl1,lhb)
	right=calculatewickets(bowl1,rhb)
	pp={}
	profile='./dataset/player_profile/nz_players_profile.txt'
	add_to_dicttabseparated(pp,profile)
	profile='./dataset/player_profile/indian_players_profile.txt'
	add_to_dicttabseparated(pp,profile)
	c1=[]
	c2=[]
	for i in rhb:
		if i in bowl1:
			c1.append(i)
	if right>left:
		for i in rhb:
			if i in bowl1:
				c2.append(i)
	else:
		for i in lhb:
			if i in bowl1:
				c2.append(i)

	name_to_var = {}
	count = 0
	for i in bowl1:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'right => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'noright => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (right(x) & noright(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((right(x)) & noright(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree1.append(p)
		return m.evaluate(query,g)
	
def generate_and_solve_query10(c1,c2,bats1,entree1):
	name_to_var = {}
	count = 0
	for i in bats1:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	
	
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'score250 => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'noduck => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (score250(x) & noduck(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((score250(x)) & noduck(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree1.append(p)
		return m.evaluate(query,g)
	

def calculateruns(bats1,player,store250,zero):
	for i in bats1:
		if i in player and int(bats1[i][1]) and i not in zero>0:
			if i in store250:
				store250[i]=store250[i]+int(bats1[i][1])
			else:
				store250[i]=int(bats1[i][1])
		elif i in player and int(bats1[i][1])==0:
			zero.append(i)


def generate_and_solve_query11(bats1,bats2,bats3,bats4,bats5,bowl1,bowl2,bowl3,bowl4,bowl5,entree1):
	c1=[]
	for i in bats1:
		if (i in bats2 or i in bowl2) and (i in bats3 or i in bowl3) and (i in bats4 or i in bowl4) and (i in bats5 or i in bowl5):
			if i not in c1:
				c1.append(i)
	for i in bowl1:
		if (i in bats2 or i in bowl2) and (i in bats3 or i in bowl3) and (i in bats4 or i in bowl4) and (i in bats5 or i in bowl5):
			if i not in c1:
				c1.append(i)
	pp={}
	profile1='./dataset/player_profile/indian_players_profile.txt'
	add_to_dicttabseparated(pp,profile1)	
	profile2='./dataset/player_profile/nz_players_profile.txt'
	add_to_dicttabseparated(pp,profile2)	
	
	name_to_var = {}
	count = 0
	for i in pp:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	
	
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'allmatches => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	v = temp_strin1 + temp_strin2
	
	query = 'exists x (allmatches(x))'
	
	if c1:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('(allmatches(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree1.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query12(sharma,jadeja):
	ws=int(sharma[0])
	wj=int(jadeja[0])
	c1=[]
	c2=[]
	if ws>wj:
		c1.append('I Sharma')
		c2.append('I Sharma')
	else:
		c1.append('I Sharma')
		c2.append('RA Jadeja')

	profile='./dataset/player_profile/indian_players_profile.txt'

	pp={}
	add_to_dicttabseparated(pp,profile)
	duckplayers=[]
	flag=0
	


	count=0	
	name_to_var = {}
	for i in pp:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'sw => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'jw => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (sw(x) & jw(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((sw(x)) & jw(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		return m.evaluate(query,g)
def generate_and_solve_query13(southee,ryder):
	ws=int(southee[0])
	wj=int(ryder[0])
	c1=[]
	c2=[]
	if ws>wj:
		c1.append('TG Southee')
		c2.append('TG Southee')
	else:
		c1.append('TG Southee')
		c2.append('JD Ryder')

	profile='./dataset/player_profile/nz_players_profile.txt'

	pp={}
	add_to_dicttabseparated(pp,profile)
	duckplayers=[]
	flag=0
	


	count=0	
	name_to_var = {}
	for i in pp:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'cs => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'cr => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (cs(x) & cr(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((cs(x)) & cr(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		return m.evaluate(query,g)

def generate_and_solve_query14(ans,entree1):
	c1=[]
	c2=[]
	flag=0
	for i in ans:
		if int(ans[i])>=2:
			c1.append(i)
			c2.append(i)
			flag=1
	
	if flag==0:
		c1.append(ans.keys()[0])
		c2.append(ans.keys()[1])

	pp={}
	profile='./dataset/player_profile/nz_players_profile.txt'
	add_to_dicttabseparated(pp,profile)
	profile='./dataset/player_profile/indian_players_profile.txt'
	add_to_dicttabseparated(pp,profile)

	count=0	
	name_to_var = {}
	for i in pp:
		if i not in name_to_var:
			name_to_var[i] = 'r' + str(count)
			count += 1
	
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'mom => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'twice => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (mom(x) & twice(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((mom(x)) & twice(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree1.append(p)
		return m.evaluate(query,g)


def generate_and_solve_query19(toss1,wonby1):
	c1=parse_for_toss(toss1)
	c2=parse_for_wonby(wonby1)
	name_to_var = {}
	count = 0
	name_to_var['India']='1'
	name_to_var['New Zealand']='2'
	name_to_var['Tie']='3'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'toss => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'wonby => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (toss(x) & wonby(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((toss(x)) & wonby(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		return m.evaluate(query,g)
def basefor16(bats1,bat,temp1):
	for i in bats1:
		if i=='MS Dhoni':
			bat=bats1
			temp1.append(heuristic16(bat))
def heuristic16(bat):
	for i in bat:
		if i=='MS Dhoni':
			return ((float(bat[i][6])*10)+(int(bat[i][5])*1000)+(100*int(bat[i][4])))
def heuristic15(bowl,inn):
	for i in bowl:
		if i=='RA Jadeja':
			return ((int(bowl[i][3])*5)+(int(bowl[i][1])*4)+(15/float(bowl[i][4])))
	
def basefor15(bowl1,inn,bowl,temp1):
	for i in bowl1:
		if i=='RA Jadeja':
			inn=1
			bowl=bowl1
			temp1.append(heuristic15(bowl,inn))
def heuristic17rj(bowl):
	for i in bowl:
		if i=='RA Jadeja':
			return ((int(bowl[i][3])*5)+(int(bowl[i][1])*4)+(15/float(bowl[i][4])))
def heuristic17is(bowl):
	for i in bowl:
		if i=='I Sharma':
			return ((int(bowl[i][3])*5)+(int(bowl[i][1])*4)+(15/float(bowl[i][4])))
def basefor17(bowl1,bowl,temp1,temp2):
	for i in bowl1:
		if i=='RA Jadeja':
			bowl=bowl1
			temp1.append(heuristic17rj(bowl))
		elif i=='I Sharma':
			bowl=bowl1
			temp2.append(heuristic17is(bowl))

def generate_and_solve_query15(m1,m2,entree):
	c1=[]
	c2=[]
	if m2>m1:
		c1.append('inn2')
		c2.append('inn2')
	else:
		c1.append('inn2')
		c2.append('inn1')
	name_to_var={}
	name_to_var['inn1']='1'
	name_to_var['inn2']='2'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'perf1 => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'perf2 => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (perf1(x) & perf2(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((perf1(x)) & perf2(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query17(m1,m2,entree):
	c1=[]
	c2=[]
	if m2>m1:
		c1.append('I Sharma')
		c2.append('I Sharma')
	else:
		c1.append('I Sharma')
		c2.append('RA Jadeja')
	name_to_var={}
	name_to_var['I Sharma']='1'
	name_to_var['RA Jadeja']='2'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'perf1 => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'perf2 => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (perf1(x) & perf2(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((perf1(x)) & perf2(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query18(op,mid,entree):
	c1=[]
	c2=[]
	if mid>op:
		c1.append('yes')
		c2.append('yes')
	else:
		c1.append('yes')
		c2.append('no')
	name_to_var={}
	name_to_var['yes']='1'
	name_to_var['no']='2'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'perf1 => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'perf2 => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (perf1(x) & perf2(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((perf1(x)) & perf2(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)
def generate_and_solve_query16(avg,entree):
	c1=[]
	c2=[]
	if avg>3000.0:
		c1.append('yes')
		c2.append('yes')
	else:
		c1.append('yes')
		c2.append('no')
	name_to_var={}
	name_to_var['yes']='1'
	name_to_var['no']='2'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'perf1 => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'perf2 => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (perf1(x) & perf2(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((perf1(x)) & perf2(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)

def heuristic18(tempdic):
	for i in tempdic:
		return ((10000*int(tempdic[i][1]))+(float(tempdic[i][6])*1000)+(int(tempdic[i][5])*100)+(10*int(tempdic[i][4])))
def readscore(temp,fname):
	f=open(fname,'r')
	index=0
	for line in f:
		if(index==2):
			break
		tempdic={}
		xx=line[:-1]
		xx=xx.split(',')
		l=xx[0]
		m=xx[1:]
		tempdic[l]=m
		temp.append(heuristic18(tempdic))
		index+=1
def readscore2(temp,fname):
	f=open(fname,'r')
	index=0
	for line in f:
		if(index<2):
			index+=1
			continue
		elif index==4:
			break
		tempdic={}
		xx=line[:-1]
		xx=xx.split(',')
		l=xx[0]
		m=xx[1:]
		tempdic[l]=m
		temp.append(heuristic18(tempdic))
		index+=1

def iterateforbat(bats1,indbat,nzbat,indianplayers,nzplayers):
	for i in bats1:
		if i in indianplayers:
			indbat.append((10000*int(bats1[i][1]))+(float(bats1[i][6])*1000)+(int(bats1[i][5])*100)+(10*int(bats1[i][4])))
		elif i in nzplayers:
			nzbat.append((10000*int(bats1[i][1]))+(float(bats1[i][6])*1000)+(int(bats1[i][5])*100)+(10*int(bats1[i][4])))

def iterateforbowl(bowl1,indbowl,nzbowl,indianplayers,nzplayers):
	for i in bowl1:
		if i in indianplayers:
			indbowl.append((int(bowl1[i][3])*5)+(int(bowl1[i][1])*4)+(15/float(bowl1[i][4])))
		elif i in nzplayers:
			nzbowl.append((int(bowl1[i][3])*5)+(int(bowl1[i][1])*4)+(15/float(bowl1[i][4])))
def generate_and_solve_query20(h1,h2,entree):
	c1=[]
	c2=[]
	if h1>h2:
		c1.append('india')
		c2.append('india')
	else:
		c1.append('new zealand')
		c2.append('new zealand')
	name_to_var={}
	name_to_var['india']='1'
	name_to_var['new zealand']='2'
	temp_strin1 = ''
	for i in name_to_var:
		temp_strin1 += i + ' => ' + name_to_var[i] + '\n'
	temp_strin2 = 'perf1 => {'
	for i in c1:
		temp_strin2 += name_to_var[i] +  ','
	temp_strin2 = temp_strin2[:-1]  #removing the extra "," character
	temp_strin2 += '} \n'
	temp_strin3 = 'perf2 => {'
	for i in c2:
		temp_strin3 += name_to_var[i] + ','
	temp_strin3 = temp_strin3[:-1]  #removing the extra "," charater
	temp_strin3 += '}'
	v = temp_strin1 + temp_strin2 + temp_strin3
	query = 'exists x (perf1(x) & perf2(x))'
	if c1 and c2:
		val = nltk.parse_valuation(v)
		dom = val.domain
		m = nltk.Model(dom, val)
		g = nltk.Assignment(dom, [])
		l = nltk.LogicParser()
		c1 = l.parse('((perf1(x)) & perf2(x))')
		varnames =  m.satisfiers(c1, 'x', g)
		for i in varnames:
			for p,q in name_to_var.iteritems():   # naive method to get key given value, in a dictionary
				if q == i:
					entree.append(p)
		return m.evaluate(query,g)




def main():
	bats1 = {}
	bowl1= {}
	bats2 = {}
	bowl2= {}
	bats3 = {}
	bowl3= {}
	bats4 = {}
	bowl4= {}
	bats5 = {}
	bowl5= {}
	mom1={}
	wonby1={}
	mom2={}
	wonby2={}
	mom3={}
	wonby3={}
	mom4={}
	wonby4={}
	mom5={}
	wonby5={}
	zeroes={}
	lostby={}

	bat11 = './dataset/match1/odi1_inn1_bat.txt'
	bat12 = './dataset/match1/odi1_inn2_bat.txt'
	bat21 = './dataset/match2/odi2_inn1_bat.txt'
	bat22 = './dataset/match2/odi2_inn2_bat.txt'
	bat31= './dataset/match3/odi3_inn1_bat.txt'
	bat32= './dataset/match3/odi3_inn2_bat.txt'
	bat41= './dataset/match4/odi4_inn1_bat.txt'
	bat42= './dataset/match4/odi4_inn2_bat.txt'
	bat51= './dataset/match5/odi5_inn1_bat.txt'
	bat52= './dataset/match5/odi5_inn2_bat.txt'
	
	bowl11 = './dataset/match1/odi1_inn1_bowl.txt'
	bowl12 = './dataset/match1/odi1_inn2_bowl.txt'
	bowl21= './dataset/match2/odi2_inn1_bowl.txt'
	bowl22= './dataset/match2/odi2_inn2_bowl.txt'
	bowl31= './dataset/match3/odi3_inn1_bowl.txt'
	bowl32= './dataset/match3/odi3_inn2_bowl.txt'
	bowl41= './dataset/match4/odi4_inn1_bowl.txt'
	bowl42= './dataset/match4/odi4_inn2_bowl.txt'
	bowl51= './dataset/match5/odi5_inn1_bowl.txt'
	bowl52= './dataset/match5/odi5_inn2_bowl.txt'
	
	t1= './dataset/match1/toss'
	t2= './dataset/match2/toss'
	t3= './dataset/match3/toss'
	t4= './dataset/match4/toss'
	t5= './dataset/match5/toss'
	
	
	
	
	mom11='./dataset/match1/mom.txt'
	wonby11='./dataset/match1/wonby.txt'
	mom22='./dataset/match2/mom.txt'
	wonby22='./dataset/match2/wonby.txt'
	lostby22='./dataset/match2/lostby.txt'
	mom33='./dataset/match3/mom.txt'
	wonby33='./dataset/match3/wonby.txt'
	mom44='./dataset/match4/mom.txt'
	wonby44='./dataset/match4/wonby.txt'
	mom55='./dataset/match5/mom.txt'
	wonby55='./dataset/match5/wonby.txt'
#####################   query1 #######################
	t=[]
	add_to_dict(mom1,mom11)
	add_to_dict(wonby1,wonby11)
	entree1=[]
	t.append(generate_and_solve_query1(mom1, wonby1,entree1))
	
	add_to_dict(mom2,mom22)
	add_to_dict(wonby2,wonby22)
	entree2=[]
	t.append(generate_and_solve_query1(mom2, wonby2,entree2))
	
	add_to_dict(mom3,mom33)
	add_to_dict(wonby3,wonby33)
	entree3=[]
	t.append(generate_and_solve_query1(mom3, wonby3,entree3))
	
	add_to_dict(mom4,mom44)
	add_to_dict(wonby4,wonby44)
	entree4=[]
	t.append(generate_and_solve_query1(mom4, wonby4,entree4))
	
	add_to_dict(mom5,mom55)
	add_to_dict(wonby5,wonby55)
	entree5=[]
	t.append(generate_and_solve_query1(mom5, wonby5,entree5))
	flag=0
	for i in t:
		if i=='False':
			flag=1
	print "The answer for the query1 is : ",
	if flag==1:
		print 'False'
	else:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5

	print
	print
############################# query 2 ######################
	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	t=[]
	wonby={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	add_to_dict(wonby,wonby11)
	entree1=[]
	t.append(generate_and_solve_query2(bats1,wonby,entree1))
	wonby={}
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	add_to_dict(wonby,wonby22)
	entree2=[]
	t.append(generate_and_solve_query2(bats2,wonby,entree2))
	wonby={}
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	add_to_dict(wonby,wonby33)
	entree3=[]
	t.append(generate_and_solve_query2(bats3,wonby,entree3))
	wonby={}
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	add_to_dict(wonby,wonby44)
	entree4=[]
	t.append(generate_and_solve_query2(bats4,wonby,entree4))
	wonby={}
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	add_to_dict(wonby,wonby55)
	entree5=[]
	t.append(generate_and_solve_query2(bats1,wonby,entree5))
	flag2=0
	for i in range(len(t)):
		if t[i]==None or t[i]==False:
			flag2=1
	print "The answer for the query2 is : ",
	if flag2==1:
		print 'False'
	else:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	print
	print
############################# query 3 ######################
	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	t=[]
	entree1=[]
	t.append(generate_and_solve_query3(bats1,entree1))
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	entree2=[]
	t.append(generate_and_solve_query3(bats2,entree2))
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	entree3=[]
	t.append(generate_and_solve_query3(bats3,entree3))
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	entree4=[]
	t.append(generate_and_solve_query3(bats4,entree4))
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	entree5=[]
	t.append(generate_and_solve_query3(bats5,entree5))
	ans=''
	flag=0
	for i in range(len(t)):
		if t[i]==False:
			flag=1
	print "The answer for the query3 is : ",
	if flag==1:
		print 'False'
	else:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	print
	print
############################# query 4 ######################
	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	t=[]
	wonby={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	add_to_dict(wonby,wonby11)
	entree1=[]
	t.append(generate_and_solve_query4(bats1,wonby,entree1))
	wonby={}
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	add_to_dict(wonby,wonby22)
	entree2=[]
	t.append(generate_and_solve_query4(bats2,wonby,entree2))
	wonby={}
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	add_to_dict(wonby,wonby33)
	entree3=[]
	t.append(generate_and_solve_query4(bats3,wonby,entree3))
	wonby={}
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	add_to_dict(wonby,wonby44)
	entree4=[]
	t.append(generate_and_solve_query4(bats4,wonby,entree4))
	wonby={}
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	add_to_dict(wonby,wonby55)
	entree5=[]
	t.append(generate_and_solve_query4(bats5,wonby,entree5))
	flag=0
	print "The answer for the query4 is : ",
	for i in t:
		if i==False:
			flag=1
	if flag==1:
		print "False"
	else:
		print "True"
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	print
	print
############################# query 5 ######################
	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	add_to_dict(bowl1,bowl11)
	add_to_dict(bowl1,bowl12)
	t=[]
	entree1=[]
	t.append(generate_and_solve_query5(bats1,bowl1,entree1))
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	add_to_dict(bowl2,bowl21)
	add_to_dict(bowl2,bowl22)
	entree2=[]
	t.append(generate_and_solve_query5(bats2,bowl2,entree2))
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	add_to_dict(bowl3,bowl31)
	add_to_dict(bowl3,bowl32)
	entree3=[]
	t.append(generate_and_solve_query5(bats3,bowl3,entree3))
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	add_to_dict(bowl4,bowl41)
	add_to_dict(bowl4,bowl42)
	entree4=[]
	t.append(generate_and_solve_query5(bats4,bowl4,entree4))
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	add_to_dict(bowl5,bowl51)
	add_to_dict(bowl5,bowl52)
	entree5=[]
	t.append(generate_and_solve_query5(bats5,bowl5,entree5))
	ans=''
	flag=0
	for i in range(len(t)):
		if t[i]==True:
			flag=1
	print "The answer for the query5 is : ",
	if flag==1:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	else:
		print 'False'
	print
	print


############################# query 6 ######################
	
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	add_to_dict(bowl1,bowl11)
	add_to_dict(bowl1,bowl12)
	t=[]
	entree1=[]
	t.append(generate_and_solve_query6(bowl1,entree1))
	add_to_dict(bowl2,bowl21)
	add_to_dict(bowl2,bowl22)
	entree2=[]
	t.append(generate_and_solve_query6(bowl2,entree2))
	add_to_dict(bowl3,bowl31)
	add_to_dict(bowl3,bowl32)
	entree3=[]
	t.append(generate_and_solve_query6(bowl3,entree3))
	add_to_dict(bowl4,bowl41)
	add_to_dict(bowl4,bowl42)
	entree4=[]
	t.append(generate_and_solve_query6(bowl4,entree4))
	add_to_dict(bowl5,bowl51)
	add_to_dict(bowl5,bowl52)
	entree5=[]
	t.append(generate_and_solve_query6(bowl5,entree5))
	ans=[]
	for i in entree1:
		if i in entree2 and i in entree3 and i in entree4 and i in entree5:
			ans.append(i)
	flag=0
	for i in range(len(t)):
		if t[i]==False:
			flag=1
	print "The answer for the query6 is : ",
	if flag==0:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	print
	print
############################# query 7 ######################
	
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	add_to_dict(bowl1,bowl11)
	add_to_dict(bowl1,bowl12)
	t=[]
	entree1=[]
	t.append(generate_and_solve_query7(bowl1,entree1))
	add_to_dict(bowl2,bowl21)
	add_to_dict(bowl2,bowl22)
	entree2=[]
	t.append(generate_and_solve_query7(bowl2,entree2))
	add_to_dict(bowl3,bowl31)
	add_to_dict(bowl3,bowl32)
	entree3=[]
	t.append(generate_and_solve_query7(bowl3,entree3))
	add_to_dict(bowl4,bowl41)
	add_to_dict(bowl4,bowl42)
	entree4=[]
	t.append(generate_and_solve_query7(bowl4,entree4))
	add_to_dict(bowl5,bowl51)
	add_to_dict(bowl5,bowl52)
	entree5=[]
	t.append(generate_and_solve_query7(bowl5,entree5))
	ans=''
	for i in entree1:
		if i in entree2 and i in entree3 and i in entree4 and i in entree5:
			ans.append(i)
	flag=0
	for i in range(len(t)):
		if t[i]==True:
			flag=1
	print "The answer for the query7 is : ",
	if flag==1:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	else:
		print 'False'
	print
	print
############################# query 8 ######################
	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	t=[]
	wonby={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	add_to_dict(wonby,wonby11)
	entree1=[]
	t.append(generate_and_solve_query8(bats1,wonby,entree1))
	
	wonby={}
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	add_to_dict(wonby,wonby22)
	entree2=[]
	t.append(generate_and_solve_query8(bats2,wonby,entree2))
	wonby={}
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	add_to_dict(wonby,wonby33)
	entree3=[]
	t.append(generate_and_solve_query8(bats3,wonby,entree3))
	wonby={}
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	add_to_dict(wonby,wonby44)
	entree4=[]
	t.append(generate_and_solve_query8(bats4,wonby,entree4))
	wonby={}
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	add_to_dict(wonby,wonby55)
	entree5=[]
	t.append(generate_and_solve_query8(bats5,wonby,entree5))
	flag=0
	for i in range(len(t)):
		if t[i]==True:
			flag=1
	print "The answer for the query8 is : ",
	if flag==1:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	else:
		print 'False'
	print
	print
############################# query 9 ######################
	
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	t=[]
	lhb=[]
	rhb=[]
	player=[]
	profile1='./dataset/player_profile/indian_players_profile.txt'
	add_to_listtabseparatedbowlers(lhb,rhb,profile1)	
	profile2='./dataset/player_profile/nz_players_profile.txt'
	add_to_listtabseparatedbowlers(lhb,rhb,profile2)	
	
	add_to_dict(bowl1,bowl11)
	add_to_dict(bowl1,bowl12)
	entree1=[]
	t.append(generate_and_solve_query9(bowl1,lhb,rhb,entree1))
	
	add_to_dict(bowl2,bowl21)
	add_to_dict(bowl2,bowl22)
	entree2=[]
	t.append(generate_and_solve_query9(bowl2,lhb,rhb,entree2))
	add_to_dict(bowl3,bowl31)
	add_to_dict(bowl1,bowl32)
	entree3=[]
	t.append(generate_and_solve_query9(bowl3,lhb,rhb,entree3))
	add_to_dict(bowl4,bowl41)
	add_to_dict(bowl4,bowl42)
	entree4=[]
	t.append(generate_and_solve_query9(bowl4,lhb,rhb,entree4))
	add_to_dict(bowl5,bowl51)
	add_to_dict(bowl5,bowl52)
	entree5=[]
	t.append(generate_and_solve_query9(bowl5,lhb,rhb,entree5))
	flag=0
	for i in t:
		if i=='False':
			flag=1
	print "The answer for the query9 is : ",
	if flag==0:
		print 'True'
		print entree1
		print entree2
		print entree3
		print entree4
		print entree5
	else:
		print 'False'
	print
	print
############################# query 10 ######################
	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	player=[]
	zero=[]
	profile1='./dataset/player_profile/indian_players_profile.txt'
	add_to_listtabseparated(player,profile1)	
	profile2='./dataset/player_profile/nz_players_profile.txt'
	add_to_listtabseparated(player,profile2)	
	store250={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	calculateruns(bats1,player,store250,zero)
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	calculateruns(bats2,player,store250,zero)
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	calculateruns(bats3,player,store250,zero)
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	calculateruns(bats4,player,store250,zero)
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	calculateruns(bats5,player,store250,zero)
#	c1=parse_for_250(store25
	c1 = []
	for i in store250:
		if int(store250[i]) > 250:
			c1.append(i)
	bats1={}
	c2=[]
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	c2=parse_for_nonzero(bats1,0)
	add_to_dict(bats1, bat21)
	add_to_dict(bats1, bat22)
	c2=parse_for_nonzero(bats1,0)
	add_to_dict(bats1, bat31)
	add_to_dict(bats1, bat32)
	c2=parse_for_nonzero(bats1,0)
	add_to_dict(bats1, bat41)
	add_to_dict(bats1, bat42)
	c2=parse_for_nonzero(bats1,0)
	add_to_dict(bats1, bat51)
	add_to_dict(bats1, bat52)
	c2=parse_for_nonzero(bats1,0)
	t=[]
	entree1=[]
	t.append(generate_and_solve_query10(c1,c2,bats1,entree1))
	print "The answer for the query10 is : ",
	print t
	print entree1
	print
	print
############### query11 ###########
	bats1={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	bowl1={}
	add_to_dict(bowl1, bowl11)
	add_to_dict(bowl1, bowl12)
	
	bats2={}
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	bowl2={}
	add_to_dict(bowl2, bowl21)
	add_to_dict(bowl2, bowl22)
	
	bats3={}
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	bowl3={}
	add_to_dict(bowl3, bowl31)
	add_to_dict(bowl3, bowl32)
	
	bats4={}
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	bowl4={}
	add_to_dict(bowl4, bowl41)
	add_to_dict(bowl4, bowl42)
	
	bats5={}
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	bowl5={}
	add_to_dict(bowl5, bowl51)
	add_to_dict(bowl5, bowl52)
	entree1=[]
	t=[]
	t.append(generate_and_solve_query11(bats1,bats2,bats3,bats4,bats5,bowl1,bowl2,bowl3,bowl4,bowl5,entree1))
	
	print "The answer for the query11 is : Players who played all the matches"
	print entree1
	print
	print
############### query12 ###########
	jadeja_wides=[]
	sharma_wides=[]
	bowl1={}
	add_to_dict(bowl1, bowl11)
	add_to_dict(bowl1, bowl12)
	calculatewides(bowl1,sharma_wides,jadeja_wides)
	bowl2={}
	add_to_dict(bowl2, bowl21)
	add_to_dict(bowl2, bowl22)
	calculatewides(bowl2,sharma_wides,jadeja_wides)
	bowl3={}
	add_to_dict(bowl3, bowl31)
	add_to_dict(bowl3, bowl32)
	calculatewides(bowl3,sharma_wides,jadeja_wides)
	bowl4={}
	add_to_dict(bowl4, bowl41)
	add_to_dict(bowl4, bowl42)
	calculatewides(bowl4,sharma_wides,jadeja_wides)
	bowl5={}
	add_to_dict(bowl5, bowl51)
	add_to_dict(bowl5, bowl52)
	calculatewides(bowl5,sharma_wides,jadeja_wides)
	t=generate_and_solve_query12(sharma_wides,jadeja_wides)
	print "The answer for the query12 is : ",
	print t
	print
	print
############### query13 ###########
	southee_caught=[]
	ryder_caught=[]
	bats1={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	calculatecatches(bats1,southee_caught,ryder_caught)
	bats2={}
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	calculatecatches(bats2,southee_caught,ryder_caught)
	bats3={}
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	calculatecatches(bats3,southee_caught,ryder_caught)
	bats4={}
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	calculatecatches(bats4,southee_caught,ryder_caught)
	bats5={}
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	calculatecatches(bats5,southee_caught,ryder_caught)
	t=generate_and_solve_query13(southee_caught,ryder_caught)
	print "The answer for the query13 is : ",
	print t
	print
	print
################## query14 ##############
	ans={}
	mom1={}
	add_to_dict(mom1,mom11)
	ans[mom1.keys()[0]]=1
	
	mom2={}
	add_to_dict(mom2,mom22)
	for i in mom2:
		if i in ans:
			ans[mom2.keys()[0]]=int(ans[mom2.keys()[0]])+1
		else:
			ans[mom2.keys()[0]]=1
	mom3={}
	add_to_dict(mom3,mom33)
	for i in mom3:
		if i in ans:
			ans[mom3.keys()[0]]=int(ans[mom3.keys()[0]])+1
		else:
			ans[mom3.keys()[0]]=1
	mom4={}
	add_to_dict(mom4,mom44)
	for i in mom4:
		if i in ans:
			ans[mom4.keys()[0]]=int(ans[mom4.keys()[0]])+1
		else:
			ans[mom4.keys()[0]]=1
	mom5={}
	add_to_dict(mom5,mom55)
	for i in mom5:
		if i in ans:
			ans[mom5.keys()[0]]=int(ans[mom5.keys()[0]])+1
		else:
			ans[mom5.keys()[0]]=1
	entree=[]
	t=generate_and_solve_query14(ans,entree)
	print "The answer for the query14 is : ",
	print t
	print entree
	print
	print
############################# query 15 ######################
	
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	bowl6={}
	bowl7={}
	bowl8={}
	bowl9={}
	bowl10={}
	
	add_to_dict(bowl1,bowl11)
	add_to_dict(bowl2,bowl12)
	inn=0
	bowl={}
	temp1=[]
	temp2=[]
	basefor15(bowl1,inn,bowl,temp1)
	basefor15(bowl2,inn,bowl,temp2)
	
	add_to_dict(bowl3,bowl21)
	add_to_dict(bowl4,bowl22)
	inn=0
	bowl={}
	basefor15(bowl3,inn,bowl,temp1)
	basefor15(bowl4,inn,bowl,temp2)
	
	add_to_dict(bowl5,bowl31)
	add_to_dict(bowl6,bowl32)
	inn=0
	bowl={}
	basefor15(bowl5,inn,bowl,temp1)
	basefor15(bowl6,inn,bowl,temp2)
	
	add_to_dict(bowl7,bowl41)
	add_to_dict(bowl8,bowl42)
	inn=0
	bowl={}
	basefor15(bowl7,inn,bowl,temp1)
	basefor15(bowl8,inn,bowl,temp2)

	add_to_dict(bowl9,bowl51)
	add_to_dict(bowl10,bowl52)
	inn=0
	bowl={}
	basefor15(bowl9,inn,bowl,temp1)
	basefor15(bowl10,inn,bowl,temp2)

	m1=sum(temp1)/len(temp1)
	m2=sum(temp2)/len(temp2)
	entree=[]
	t=generate_and_solve_query15(m1,m2,entree)
	print 'Solution to query15:    Sir Jadeja performed well in:',
	print entree
	print
	print
############ query16  #########

	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	temp1=[]
	
	add_to_dict(bats1,bat11)
	add_to_dict(bats1,bat12)
	bat={}
	basefor16(bats1,bat,temp1)

	add_to_dict(bats2,bat21)
	add_to_dict(bats2,bat22)
	bat={}
	basefor16(bats2,bat,temp1)

	add_to_dict(bats3,bat31)
	add_to_dict(bats3,bat32)
	bat={}
	basefor16(bats3,bat,temp1)

	add_to_dict(bats4,bat41)
	add_to_dict(bats4,bat42)
	bat={}
	basefor16(bats4,bat,temp1)
	add_to_dict(bats5,bat51)
	add_to_dict(bats5,bat52)
	bat={}
	basefor16(bats5,bat,temp1)
	avg=sum(temp1)/len(temp1)
	entree=[]
	t=generate_and_solve_query16(avg,entree)
	print 'Solution to query16:    Is Dhoni hard hitting batsman:',
	print entree
	print
	print
	
############################# query 17 ######################
	
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	
	add_to_dict(bowl1,bowl11)
	add_to_dict(bowl1,bowl12)
	bowl={}
	temp1=[]
	temp2=[]
	basefor17(bowl1,bowl,temp1,temp2)
	add_to_dict(bowl2,bowl21)
	add_to_dict(bowl2,bowl22)
	bowl={}
	basefor17(bowl2,bowl,temp1,temp2)
	
	add_to_dict(bowl3,bowl31)
	add_to_dict(bowl3,bowl32)
	bowl={}
	basefor17(bowl3,bowl,temp1,temp2)
	
	add_to_dict(bowl4,bowl41)
	add_to_dict(bowl4,bowl42)
	bowl={}
	basefor17(bowl4,bowl,temp1,temp2)
	
	add_to_dict(bowl5,bowl51)
	add_to_dict(bowl5,bowl52)
	bowl={}
	basefor17(bowl5,bowl,temp1,temp2)
	m1=sum(temp1)/len(temp1)
	m2=sum(temp2)/len(temp2)
	entree=[]
	t=generate_and_solve_query17(m1,m2,entree)
	print 'Solution to query17:    Is Ishant Sharma a better bowler than Sir Jadeja:',
	print t
	print
	print
############ query18  #########

	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	tempop=[]
	tempmid=[]
	

	readscore(tempop,bat11)
	readscore(tempop,bat12)
	readscore(tempop,bat21)
	readscore(tempop,bat22)
	readscore(tempop,bat31)
	readscore(tempop,bat32)
	readscore(tempop,bat41)
	readscore(tempop,bat42)
	readscore(tempop,bat51)
	readscore(tempop,bat52)

	readscore2(tempmid,bat11)
	readscore2(tempmid,bat12)
	readscore2(tempmid,bat21)
	readscore2(tempmid,bat22)
	readscore2(tempmid,bat31)
	readscore2(tempmid,bat32)
	readscore2(tempmid,bat41)
	readscore2(tempmid,bat42)
	readscore2(tempmid,bat51)
	readscore2(tempmid,bat52)
	op=sum(tempop)/len(tempop)
	mid=sum(tempmid)/len(tempmid)
	entree=[]
	t=generate_and_solve_query18(op,mid,entree)
	print 'Solution to query18:    Do the middle order batsmen perform better than opening batsmen:',
	print entree
	print
	print
######### query 19 ###############
	t=[]
	toss1={}
	add_to_dict(toss1,t1)
	wonby1={}
	add_to_dict(wonby1,wonby11)
	t.append(generate_and_solve_query19(toss1,wonby1))
	toss2={}
	add_to_dict(toss2,t2)
	wonby2={}
	add_to_dict(wonby2,wonby22)
	t.append(generate_and_solve_query19(toss2,wonby2))
	toss3={}
	add_to_dict(toss3,t3)
	wonby3={}
	add_to_dict(wonby3,wonby33)
	t.append(generate_and_solve_query19(toss3,wonby3))
	toss4={}
	add_to_dict(toss4,t4)
	wonby4={}
	add_to_dict(wonby4,wonby44)
	t.append(generate_and_solve_query19(toss4,wonby4))
	toss5={}
	add_to_dict(toss5,t5)
	wonby5={}
	add_to_dict(wonby5,wonby55)
	t.append(generate_and_solve_query19(toss5,wonby5))
	flag=0
	print "The answer for the query19 is : ",
	for i in t:
		if i==False:
			flag=1
	if flag==1:
		print 'False'
	else:
		print 'True'
	print
	print
############## query20  ##############
	bats1={}
	bats2={}
	bats3={}
	bats4={}
	bats5={}
	bowl1={}
	bowl2={}
	bowl3={}
	bowl4={}
	bowl5={}
	add_to_dict(bats1, bat11)
	add_to_dict(bats1, bat12)
	add_to_dict(bowl1,bowl11)
	add_to_dict(bowl1,bowl12)
	t=[]
	entree1=[]
	add_to_dict(bats2, bat21)
	add_to_dict(bats2, bat22)
	add_to_dict(bowl2,bowl21)
	add_to_dict(bowl2,bowl22)
	entree2=[]
	add_to_dict(bats3, bat31)
	add_to_dict(bats3, bat32)
	add_to_dict(bowl3,bowl31)
	add_to_dict(bowl3,bowl32)
	entree3=[]
	add_to_dict(bats4, bat41)
	add_to_dict(bats4, bat42)
	add_to_dict(bowl4,bowl41)
	add_to_dict(bowl4,bowl42)
	entree4=[]
	add_to_dict(bats5, bat51)
	add_to_dict(bats5, bat52)
	add_to_dict(bowl5,bowl51)
	add_to_dict(bowl5,bowl52)
	entree5=[]
	
	profile1='./dataset/player_profile/indian_players_profile.txt'
	profile2='./dataset/player_profile/nz_players_profile.txt'

	temp=[]
	indianplayers=[]
	nzplayers=[]
	add_to_listfinal(profile1,indianplayers)
	add_to_listfinal(profile2,nzplayers)
	



	nzbat=[]
	nzbowl=[]
	indbat=[]
	indbowl=[]

	indbatavg=[]
	indbowlavg=[]
	nzbatavg=[]
	nzbowlavg=[]
	wonby1={}
	add_to_dict(wonby1,wonby11)
	wonby2={}
	add_to_dict(wonby2,wonby22)
	wonby3={}
	add_to_dict(wonby3,wonby33)
	wonby4={}
	add_to_dict(wonby4,wonby44)
	wonby5={}
	add_to_dict(wonby5,wonby55)

	iterateforbat(bats1,indbat,nzbat,indianplayers,nzplayers)
	if wonby1.keys()[0]=='India':
		for i in range(len(indbat)):
			indbat[i]*=2
	if wonby1.keys()[0]=='New Zealnad':
		for i in range(len(nzbat)):
			nzbat[i]*=2

	indbatavg.append(float(sum(indbat)/len(indbat)))
	nzbatavg.append(float(sum(nzbat)/len(nzbat)))
	nzbat=[]
	indbat=[]

	iterateforbat(bats2,indbat,nzbat,indianplayers,nzplayers)
	if wonby2.keys()[0]=='India':
		for i in range(len(indbat)):
			indbat[i]*=2
	if wonby2.keys()[0]=='New Zealnad':
		for i in range(len(nzbat)):
			nzbat[i]*=2
	indbatavg.append(float(sum(indbat)/len(indbat)))
	nzbatavg.append(float(sum(nzbat)/len(nzbat)))
	nzbat=[]
	indbat=[]
	
	iterateforbat(bats3,indbat,nzbat,indianplayers,nzplayers)
	if wonby3.keys()[0]=='India':
		for i in range(len(indbat)):
			indbat[i]*=2
	if wonby3.keys()[0]=='New Zealnad':
		for i in range(len(nzbat)):
			nzbat[i]*=2
	indbatavg.append(float(sum(indbat)/len(indbat)))
	nzbatavg.append(float(sum(nzbat)/len(nzbat)))
	nzbat=[]
	indbat=[]
	
	iterateforbat(bats4,indbat,nzbat,indianplayers,nzplayers)
	if wonby4.keys()[0]=='India':
		for i in range(len(indbat)):
			indbat[i]*=2
	if wonby4.keys()[0]=='New Zealnad':
		for i in range(len(nzbat)):
			nzbat[i]*=2
	indbatavg.append(float(sum(indbat)/len(indbat)))
	nzbatavg.append(float(sum(nzbat)/len(nzbat)))
	nzbat=[]
	indbat=[]
	
	iterateforbat(bats5,indbat,nzbat,indianplayers,nzplayers)
	if wonby5.keys()[0]=='India':
		for i in range(len(indbat)):
			indbat[i]*=2
	if wonby5.keys()[0]=='New Zealnad':
		for i in range(len(nzbat)):
			nzbat[i]*=2
	indbatavg.append(float(sum(indbat)/len(indbat)))
	nzbatavg.append(float(sum(nzbat)/len(nzbat)))
	nzbat=[]
	indbat=[]

	iterateforbowl(bowl1,indbowl,nzbowl,indianplayers,nzplayers)
	if wonby1.keys()[0]=='India':
		for i in range(len(indbowl)):
			indbowl[i]*=2
	if wonby1.keys()[0]=='New Zealnad':
		for i in range(len(nzbowl)):
			nzbowl[i]*=2

	indbowlavg.append(float(sum(indbowl)/len(indbowl)))
	nzbowlavg.append(float(sum(nzbowl)/len(nzbowl)))
	nzbowl=[]
	indbowl=[]
	
	
	iterateforbowl(bowl2,indbowl,nzbowl,indianplayers,nzplayers)
	if wonby2.keys()[0]=='India':
		for i in range(len(indbowl)):
			indbowl[i]*=2
	if wonby2.keys()[0]=='New Zealnad':
		for i in range(len(nzbowl)):
			nzbowl[i]*=2

	indbowlavg.append(float(sum(indbowl)/len(indbowl)))
	nzbowlavg.append(float(sum(nzbowl)/len(nzbowl)))
	nzbowl=[]
	indbowl=[]
	
	iterateforbowl(bowl3,indbowl,nzbowl,indianplayers,nzplayers)
	if wonby3.keys()[0]=='India':
		for i in range(len(indbowl)):
			indbowl[i]*=2
	if wonby3.keys()[0]=='New Zealnad':
		for i in range(len(nzbowl)):
			nzbowl[i]*=2
	indbowlavg.append(float(sum(indbowl)/len(indbowl)))
	nzbowlavg.append(float(sum(nzbowl)/len(nzbowl)))
	nzbowl=[]
	indbowl=[]
	
	iterateforbowl(bowl4,indbowl,nzbowl,indianplayers,nzplayers)
	if wonby4.keys()[0]=='India':
		for i in range(len(indbowl)):
			indbowl[i]*=2
	if wonby4.keys()[0]=='New Zealnad':
		for i in range(len(nzbowl)):
			nzbowl[i]*=2
	indbowlavg.append(float(sum(indbowl)/len(indbowl)))
	nzbowlavg.append(float(sum(nzbowl)/len(nzbowl)))
	nzbowl=[]
	indbowl=[]
	
	iterateforbowl(bowl5,indbowl,nzbowl,indianplayers,nzplayers)
	if wonby5.keys()[0]=='India':
		for i in range(len(indbowl)):
			indbowl[i]*=2
	if wonby5.keys()[0]=='New Zealnad':
		for i in range(len(nzbowl)):
			nzbowl[i]*=2
	indbowlavg.append(float(sum(indbowl)/len(indbowl)))
	nzbowlavg.append(float(sum(nzbowl)/len(nzbowl)))
	nzbowl=[]
	indbowl=[]
	btaind=float(sum(indbatavg)/len(indbatavg))
	btanz=float(sum(nzbatavg)/len(nzbatavg))
	blaind=float(sum(indbowlavg)/len(indbowlavg))
	blanz=float(sum(nzbowlavg)/len(nzbowlavg))
	
	h1=btaind+50*blaind
	h2=btanz+50*blanz
	t=[]
	entree=[]
	t.append(generate_and_solve_query20(h1,h2,entree))
	print 'Solution of query20:   Outcome of next match: ',
	print entree

	print
	print

	
if __name__ == "__main__":
	main()
